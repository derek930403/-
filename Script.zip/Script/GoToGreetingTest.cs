using UnityEngine;
using UnityEngine.SceneManagement;

public class GoToGreetingTest : MonoBehaviour
{
    public void To_Main()
    {
        SceneManager.LoadScene("Greeting_test");
    }
}
