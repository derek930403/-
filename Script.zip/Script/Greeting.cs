﻿using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Greeting : MonoBehaviour
{
    [Header("對話區域")]
    [SerializeField] private TMP_Text GreetingArea;

    [Header("按鈕")]
    [SerializeField] private Button to_AI_Chat;
    [SerializeField] private Button to_Diary;
    [SerializeField] private Button to_Rank;
    [SerializeField] private Button to_map;
    [SerializeField] private Button to_postcard;
    [SerializeField] private Button to_Login;
    [SerializeField] private Button to_Greeting_test;
    [SerializeField] private Button to_act;
    [SerializeField] private Button to_call;

    private string[] greetings = {
        "嗨，今天也是美好的一天!",
        "準備好了嗎？",
        "又見面了！",
        "祝你過得開心！"
    };

    void Start()
    {
        Greet();
    }

    private void Greet()
    {
        int index = Random.Range(0, greetings.Length);
        string selectedGreeting = greetings[index];
        Debug.Log("[Greeting] 顯示問候語：" + selectedGreeting);
        GreetingArea.text = selectedGreeting;
    }

    public void To_AI_Chat()
    {
        SceneManager.LoadScene("AI_Chat"); // 請確認此名稱與 Build Settings 一致
    }

    public void To_Rank()
    {
        SceneManager.LoadScene("Rank"); // 同上
    }

    public void To_Diary()
    {
        // 正確寫法：使用場景名稱（不含路徑）
        SceneManager.LoadScene("GreetingScene");
    }

    public void To_map()
    {
        SceneManager.LoadScene("Location-basedGame"); // 同上
    }

    public void To_postcard()
    {
        SceneManager.LoadScene("DiaryDisplayScene"); // 同上
    }
    public void To_Login()
    {
        SceneManager.LoadScene("Login"); // 同上
    }
    public void To_Main()
    {
        SceneManager.LoadScene("Greeting_test"); // 同上
    }
    public void To_act()
    {
        SceneManager.LoadScene("activityScene"); // 同上
    }
    public void To_call()
    {
        SceneManager.LoadScene("SampleScene"); // 同上
    }

}
