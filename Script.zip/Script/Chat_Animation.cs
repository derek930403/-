﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Chat_Animation : MonoBehaviour
{
   

    [SerializeField] Button chat_btn;
    [SerializeField] Animator ani;


    public string triggerName = "Play";  // 你動畫的Trigger名稱

    private bool hasPlayed = false;   // 記錄是否已播放過動畫

    public void Start()
    {
        chat_btn.onClick.AddListener(send);
    }

    public void send()
    {
        Debug.Log("press!");
        if (!hasPlayed)
        {
            Debug.Log("act!!");
            ani.SetTrigger(triggerName);  // 播放動畫
            hasPlayed = true;                 // 記錄已播放
        }
        else
        {
            // 不做事，或執行其他非動畫邏輯
        }
    }
}

