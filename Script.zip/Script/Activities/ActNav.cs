using UnityEngine;

namespace YNTX.Activities
{
    public static class ActNav
    {
        private const string kKey = "ActLastCat";
        public static ActCategory LastCategory = ActCategory.Roam;

        public static void Save(ActCategory cat)
        {
            LastCategory = cat;
            PlayerPrefs.SetInt(kKey, (int)cat);
            PlayerPrefs.Save();
        }

        public static ActCategory Load()
        {
            var val = PlayerPrefs.GetInt(kKey, (int)ActCategory.Roam);
            LastCategory = (ActCategory)val;
            return LastCategory;
        }
    }
}
