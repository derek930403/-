using System.Collections.Generic;
using UnityEngine;

namespace YNTX.Activities
{
    [DefaultExecutionOrder(-5)]
    public class ActivityJsonLoader_Resources : MonoBehaviour
    {
        [Header("���W ActivitySceneController")]
        public ActivitySceneController controller;

        [Header("Resources �U���ɦW�]���ΰ��ɦW�^")]
        public string resourceName = "Activities"; // ���� Assets/Resources/Activities.json

        void Awake()
        {
            // 0) �� Controller
            if (!controller)
            {
                controller = FindObjectOfType<ActivitySceneController>();
                if (!controller)
                {
                    Debug.LogError("[ActivityJsonLoader] �䤣�� ActivitySceneController");
                    return;
                }
            }

            // 1) Ū TextAsset
            var ta = Resources.Load<TextAsset>(resourceName);
            if (!ta || string.IsNullOrWhiteSpace(ta.text))
            {
                Debug.LogError($"[ActivityJsonLoader] �ʤ֩Ϊťժ� Resources/{resourceName}.json");
                controller.data = new List<ActCategoryBucket>(); // ���Ŷ��X�A�קK���� Null
                return;
            }

            // 2) �ѪR JSON�]�䴩���h�}�C�^
            List<ActCategoryBucket> buckets = null;
            try
            {
                buckets = JsonUtilityList.FromJsonList<ActCategoryBucket>(ta.text);
            }
            catch (System.SystemException e)
            {
                Debug.LogError($"[ActivityJsonLoader] �ѪR JSON ���ѡG{e.Message}");
            }

            // 3) ���b��z�G�O�ҫD null�A�ùL�o/��� bucket �P items
            if (buckets == null)
            {
                Debug.LogWarning("[ActivityJsonLoader] �ѪR���G�� null�A��ΪŲM��");
                buckets = new List<ActCategoryBucket>();
            }

            for (int i = buckets.Count - 1; i >= 0; i--)
            {
                var b = buckets[i];
                if (b == null)
                {
                    Debug.LogWarning($"[ActivityJsonLoader] buckets[{i}] �O null�A�w����");
                    buckets.RemoveAt(i);
                    continue;
                }
                if (b.items == null)
                {
                    Debug.LogWarning($"[ActivityJsonLoader] {b.categoryEnum} �� items �� null �� �ɪŲM��");
                    b.items = new List<ActItem>();
                }
                else
                {
                    // ���� null item�A�קK BuildList �ɦs�� it.name ����
                    int removed = b.items.RemoveAll(x => x == null);
                    if (removed > 0)
                        Debug.LogWarning($"[ActivityJsonLoader] {b.categoryEnum} ���� {removed} �� null ActItem");
                }
            }

            // 4) ������ Controller �è�s
            controller.data = buckets;
            controller.RefreshLists();

            Debug.Log($"[ActivityJsonLoader] ���J�����G{buckets.Count} �Ӥ�����");
        }
    }
}
