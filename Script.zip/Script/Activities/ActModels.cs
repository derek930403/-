using System;
using System.Collections.Generic;
using UnityEngine;

namespace YNTX.Activities
{
    // �����C�|
    public enum ActCategory { Roam, Sport, Study, Entertain }

    // ���ʶ���
    [Serializable]
    public class ActItem
    {
        public string id;
        public string name;
        public string time;
        public string location;
        [TextArea(2, 6)]
        public string description;
        public string url; // �i��
    }

    // �������GJSON �Φr�� "Roam"�A�ϧǦC�ƫ�۰��ন Enum
    [Serializable]
    public class ActCategoryBucket : ISerializationCallbackReceiver
    {
        public string category;             // JSON: "Roam"/"Sport"/"Study"/"Entertain"
        public List<ActItem> items;         // �Ӥ��������ʲM��

        [NonSerialized] public ActCategory categoryEnum; // �ѵ{���ϥ�

        public void OnAfterDeserialize()
        {
            if (!Enum.TryParse(category, true, out categoryEnum))
            {
                Debug.LogWarning($"[ActCategoryBucket] �L�k�ѪR���O: {category}�A�w�]�� Roam");
                categoryEnum = ActCategory.Roam;
            }
        }

        public void OnBeforeSerialize()
        {
            category = categoryEnum.ToString();
        }
    }

    // JsonUtility ���䴩���h List�A�]�_�ӸѪR
    public static class JsonUtilityList
    {
        [Serializable] private class Wrapper<T> { public List<T> items; }

        public static List<T> FromJsonList<T>(string jsonArray)
        {
            string wrapped = "{\"items\":" + jsonArray + "}";
            var w = JsonUtility.FromJson<Wrapper<T>>(wrapped);
            return w?.items ?? new List<T>();
        }
    }

    // ���������֨��]�ߤ@��m�G��o�̡^
    public static class ActSelection
    {
        public static string SelectedId;
        public static ActItem SelectedItem;
    }
}
