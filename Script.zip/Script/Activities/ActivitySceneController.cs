using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

namespace YNTX.Activities
{
    [DefaultExecutionOrder(-100)]   // 確保在其他物件之前執行
    public class ActivitySceneController : MonoBehaviour
    {
        [Header("==== 主類別 Panels (4 種) ====")]
        public GameObject roamMainPanel;
        public GameObject sportMainPanel;
        public GameObject studyMainPanel;
        public GameObject entertainMainPanel;

        [Header("==== 子清單 Panels (4 種) ====")]
        public GameObject roamListPanel;
        public GameObject sportListPanel;
        public GameObject studyListPanel;
        public GameObject entertainListPanel;

        [Header("==== 各清單 Content (ScrollView/Viewport/Content) ====")]
        public Transform roamListContent;
        public Transform sportListContent;
        public Transform studyListContent;
        public Transform entertainListContent;

        [Header("==== 上方分類按鈕 (主類別) ====")]
        public Button btnRoam;
        public Button btnSport;
        public Button btnStudy;
        public Button btnEntertain;

        [Header("==== 主類別進入清單的按鈕 (進入子清單) ====")]
        public Button roamEnterBtn;
        public Button sportEnterBtn;
        public Button studyEnterBtn;
        public Button entertainEnterBtn;

        [Header("==== 子清單的 Row Prefab (需包含 NameText，用來顯示名稱) ====")]
        public GameObject rowPrefab;

        [Header("==== 資料來源 (由 JsonLoader 載入) ====")]
        public List<ActCategoryBucket> data = new List<ActCategoryBucket>();

        Dictionary<ActCategory, GameObject> mainMap;
        Dictionary<ActCategory, GameObject> listMap;
        Dictionary<ActCategory, Transform> contentMap;

        void Awake()
        {
            mainMap = new Dictionary<ActCategory, GameObject>
            {
                { ActCategory.Roam, roamMainPanel },
                { ActCategory.Sport, sportMainPanel },
                { ActCategory.Study, studyMainPanel },
                { ActCategory.Entertain, entertainMainPanel },
            };
            listMap = new Dictionary<ActCategory, GameObject>
            {
                { ActCategory.Roam, roamListPanel },
                { ActCategory.Sport, sportListPanel },
                { ActCategory.Study, studyListPanel },
                { ActCategory.Entertain, entertainListPanel },
            };
            contentMap = new Dictionary<ActCategory, Transform>
            {
                { ActCategory.Roam, roamListContent },
                { ActCategory.Sport, sportListContent },
                { ActCategory.Study, studyListContent },
                { ActCategory.Entertain, entertainListContent },
            };

            // 上方分類按鈕：切換主類別
            if (btnRoam) btnRoam.onClick.AddListener(() => { ActNav.Save(ActCategory.Roam); ShowMain(ActCategory.Roam); });
            if (btnSport) btnSport.onClick.AddListener(() => { ActNav.Save(ActCategory.Sport); ShowMain(ActCategory.Sport); });
            if (btnStudy) btnStudy.onClick.AddListener(() => { ActNav.Save(ActCategory.Study); ShowMain(ActCategory.Study); });
            if (btnEntertain) btnEntertain.onClick.AddListener(() => { ActNav.Save(ActCategory.Entertain); ShowMain(ActCategory.Entertain); });

            // 主類別面板內的進入清單按鈕
            if (roamEnterBtn) roamEnterBtn.onClick.AddListener(() => { ActNav.Save(ActCategory.Roam); ShowList(ActCategory.Roam); });
            if (sportEnterBtn) sportEnterBtn.onClick.AddListener(() => { ActNav.Save(ActCategory.Sport); ShowList(ActCategory.Sport); });
            if (studyEnterBtn) studyEnterBtn.onClick.AddListener(() => { ActNav.Save(ActCategory.Study); ShowList(ActCategory.Study); });
            if (entertainEnterBtn) entertainEnterBtn.onClick.AddListener(() => { ActNav.Save(ActCategory.Entertain); ShowList(ActCategory.Entertain); });
        }

        void Start()
        {
            // 初始化：讀取上次使用的分類 (預設 Roam)
            var startCat = ActNav.Load();
            SetAllMain(false);
            SetAllList(false);
            if (mainMap.TryGetValue(startCat, out var startPanel) && startPanel)
            {
                startPanel.SetActive(true);
                EnsurePanelRaycast(startPanel, true);
            }

            if (data != null && data.Count > 0) RefreshLists();
        }

        public void RefreshLists()
        {
            if (data == null) return;
            foreach (var bucket in data)
            {
                if (bucket == null)
                {
                    Debug.LogWarning("[ActivitySceneController] data 包含 null bucket，已忽略。");
                    continue;
                }
                BuildList(bucket.categoryEnum, bucket.items);
            }
        }

        void SetAllMain(bool on)
        {
            foreach (var kv in mainMap)
                if (kv.Value)
                {
                    kv.Value.SetActive(on);
                    EnsurePanelRaycast(kv.Value, on);
                }
        }

        void ShowMain(ActCategory cat)
        {
            SetAllList(false);
            SetAllMain(false);
            if (mainMap.TryGetValue(cat, out var panel) && panel)
            {
                panel.SetActive(true);
                EnsurePanelRaycast(panel, true);
            }
        }

        void SetAllList(bool on)
        {
            foreach (var kv in listMap)
                if (kv.Value)
                {
                    kv.Value.SetActive(on);
                    EnsurePanelRaycast(kv.Value, on);
                }
        }

        void ShowList(ActCategory cat)
        {
            ActNav.Save(cat); // 記錄目前進入的子清單分類

            SetAllMain(false);
            SetAllList(false);

            if (contentMap.TryGetValue(cat, out var content) && content && content.childCount == 0)
            {
                var items = FindItems(cat);
                BuildList(cat, items);
            }

            if (listMap.TryGetValue(cat, out var panel) && panel)
            {
                panel.SetActive(true);
                EnsurePanelRaycast(panel, true);
            }
        }

        List<ActItem> FindItems(ActCategory cat)
        {
            if (data == null) return null;
            foreach (var b in data)
                if (b.categoryEnum == cat) return b.items;
            return null;
        }

        void ClearChildren(Transform t)
        {
            if (!t) return;
            for (int i = t.childCount - 1; i >= 0; i--)
                Destroy(t.GetChild(i).gameObject);
        }

        void BuildList(ActCategory cat, List<ActItem> items)
        {
            if (!contentMap.TryGetValue(cat, out var content) || !content) return;
            ClearChildren(content);
            if (items == null || rowPrefab == null) return;

            foreach (var it in items)
            {
                if (it == null) { Debug.LogWarning($"[BuildList] {cat} 出現 null ActItem，已忽略。"); continue; }

                var rowGO = Instantiate(rowPrefab, content);
                var currentCat = cat;

                // 1) name / time
                TMP_Text nameText = null;
                foreach (var tx in rowGO.GetComponentsInChildren<TMP_Text>(true))
                {
                    var n = tx.name.ToLowerInvariant();
                    if (n.Contains("name")) nameText = tx;
                    else if (n.Contains("time")) tx.gameObject.SetActive(false);
                    tx.raycastTarget = false;
                }
                if (nameText) nameText.text = it.name ?? "";

                // 2) Button
                var btn = rowGO.GetComponentInChildren<Button>(true);
                Image img = null;
                if (btn == null)
                {
                    img = rowGO.GetComponent<Image>() ?? rowGO.AddComponent<Image>();
                    img.color = new Color(0, 0, 0, 0);
                    img.raycastTarget = true;
                    btn = rowGO.AddComponent<Button>();
                }
                else
                {
                    img = btn.targetGraphic as Image ?? btn.GetComponent<Image>() ?? rowGO.GetComponent<Image>() ?? rowGO.AddComponent<Image>();
                    img.color = new Color(0, 0, 0, 0);
                    img.raycastTarget = true;
                    btn.targetGraphic = img;
                }

                var btnRT = btn.GetComponent<RectTransform>();
                btnRT.anchorMin = Vector2.zero; btnRT.anchorMax = Vector2.one;
                btnRT.offsetMin = Vector2.zero; btnRT.offsetMax = Vector2.zero;

                btn.onClick.RemoveAllListeners();
                btn.onClick.AddListener(() =>
                {
                    Debug.Log($"[ActivityRow CLICK] {it.name} (id={it.id})");
                    ActSelection.SelectedItem = it;
                    ActNav.Save(currentCat);
                    CharacterDialogController.MarkSkipNextGreetingOnce();
                    var bg = rowGO.GetComponent<Image>(); if (bg) bg.color = new Color(1, 1, 1, 0.15f);
                    SceneManager.LoadSceneAsync("ActivityListScene", LoadSceneMode.Single);
                });
            }
        }

        // ===== 輔助：確保 Panel 可以被點擊 (使用 CanvasGroup) =====
        void EnsurePanelRaycast(GameObject panel, bool on)
        {
            if (!panel) return;
            var cg = panel.GetComponent<CanvasGroup>();
            if (cg == null) cg = panel.AddComponent<CanvasGroup>();
            cg.blocksRaycasts = on;
            cg.interactable = on;
            // alpha 不動，避免影響視覺
        }
    }
}
