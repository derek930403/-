using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class InfoPanelController : MonoBehaviour
{
    public static InfoPanelController Instance;

    public GameObject panel;
    public TextMeshProUGUI nameText;
    public TextMeshProUGUI descriptionText;
    public Button closeButton;

    private void Awake()
    {
        Instance = this;
        panel.SetActive(false);

        closeButton.onClick.AddListener(() =>
        {
            panel.SetActive(false);
        });
    }

    public void ShowInfo(POIData data)
    {
        nameText.text = data.poiName;
        
        panel.SetActive(true);
    }
}
