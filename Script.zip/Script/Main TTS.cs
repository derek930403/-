using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using System.IO;

[RequireComponent(typeof(AudioSource))]
public class MainTTS : MonoBehaviour
{
    [Header("ElevenLabs API Key")]
    public string apiKey;

    [Header("Voice ID")]
    public string voiceID;

    public TextMeshProUGUI textSource;
 
    private string lastText = "";
    private AudioSource audioSource;

    void Start()
    {
        if (textSource == null)
        {
            GameObject target = GameObject.Find("問候");
            if (target != null)
                textSource = target.GetComponent<TextMeshProUGUI>();
            else
            {
                Debug.LogError("找不到文字框");
                return;
            }
        }

        audioSource = GetComponent<AudioSource>();
        StartCoroutine(CheckTextRoutine());
    }

    IEnumerator CheckTextRoutine()
    {
        while (true)
        {
            string currentText = textSource.text.Trim();
            if (!string.IsNullOrEmpty(currentText) && currentText != lastText)
            {
                lastText = currentText;
                yield return StartCoroutine(Speak(currentText));
            }
            yield return new WaitForSeconds(0.2f);
        }
    }

    IEnumerator Speak(string text)
    {
        string apiUrl = $"https://api.elevenlabs.io/v1/text-to-speech/{voiceID}?output_format=pcm_16000";
        string json = $"{{\"text\":\"{text}\",\"model_id\":\"eleven_multilingual_v2\"}}";

        UnityWebRequest request = new UnityWebRequest(apiUrl, "POST");
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(json);
        request.uploadHandler = new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        request.SetRequestHeader("xi-api-key", apiKey);

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            byte[] pcmData = request.downloadHandler.data;

            // 轉 WAV
            string wavPath = Path.Combine(Application.persistentDataPath, "temp_tts.wav");
            SavePcmAsWav(pcmData, wavPath, 16000, 1); 

            // 播放 WAV
            using (UnityWebRequest audioReq = UnityWebRequestMultimedia.GetAudioClip("file://" + wavPath, AudioType.WAV))
            {
                yield return audioReq.SendWebRequest();

                if (audioReq.result == UnityWebRequest.Result.Success)
                {
                    AudioClip clip = DownloadHandlerAudioClip.GetContent(audioReq);
                    audioSource.clip = clip;
                    audioSource.Play();
                }
                else
                {
                    Debug.LogError("讀取音訊失敗: " + audioReq.error);
                }
            }
        }
        else
        {
            Debug.LogError("API錯誤：" + request.responseCode + "\n內容：" + request.downloadHandler.text);
        }
    }

    // PCM bytes 轉 WAV
    void SavePcmAsWav(byte[] pcmData, string path, int sampleRate, int channels)
    {
        int headerSize = 44;
        int dataSize = pcmData.Length;
        byte[] wavData = new byte[headerSize + dataSize];

        // WAV header
        System.Text.Encoding.ASCII.GetBytes("RIFF").CopyTo(wavData, 0);
        System.BitConverter.GetBytes(36 + dataSize).CopyTo(wavData, 4);
        System.Text.Encoding.ASCII.GetBytes("WAVE").CopyTo(wavData, 8);
        System.Text.Encoding.ASCII.GetBytes("fmt ").CopyTo(wavData, 12);
        System.BitConverter.GetBytes(16).CopyTo(wavData, 16); 
        System.BitConverter.GetBytes((short)1).CopyTo(wavData, 20); 
        System.BitConverter.GetBytes((short)channels).CopyTo(wavData, 22);
        System.BitConverter.GetBytes(sampleRate).CopyTo(wavData, 24);
        System.BitConverter.GetBytes(sampleRate * channels * 2).CopyTo(wavData, 28); 
        System.BitConverter.GetBytes((short)(channels * 2)).CopyTo(wavData, 32); 
        System.BitConverter.GetBytes((short)16).CopyTo(wavData, 34); 
        System.Text.Encoding.ASCII.GetBytes("data").CopyTo(wavData, 36);
        System.BitConverter.GetBytes(dataSize).CopyTo(wavData, 40);
        pcmData.CopyTo(wavData, headerSize);

        File.WriteAllBytes(path, wavData);
    }
}
