using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using TMPro;

public class POIInfoPanel : MonoBehaviour
{
    [Header("UI Refs")]
    public GameObject panel;

    [Tooltip("��ܦa�I�Ӥ��� Image�]UI �� Image�^")]
    public Image photoImage;

    [Tooltip("�S���Ӥ�����ܪ��w�]��")]
    public Sprite noPhotoSprite;

    public TMP_Text nameTMP;
    public TMP_Text categoryTMP;
    public TMP_Text servicesTMP;
    public TMP_Text phoneTMP;
    public TMP_Text addressTMP;

    public Button closeButton;
    public Button navigateButton;

    // �U���ϥ�
    Coroutine _photoCo;
    string _currentUrl;

    void Awake()
    {
        if (closeButton) closeButton.onClick.AddListener(Hide);
    }

    public void Hide()
    {
        if (_photoCo != null) { StopCoroutine(_photoCo); _photoCo = null; }
        if (panel) panel.SetActive(false);
    }

    // �~���I�s�G��ܬY�� POI ����T
    public void Show(POIData data)
    {
        if (!panel) return;
        panel.SetActive(true);

        // ��r���
        if (nameTMP) nameTMP.text = string.IsNullOrWhiteSpace(data.poiName) ? "�L" : data.poiName;
        if (categoryTMP) categoryTMP.text = string.IsNullOrWhiteSpace(data.category) ? "�L" : data.category;
        if (servicesTMP) servicesTMP.text = string.IsNullOrWhiteSpace(data.services) ? "�L" : data.services;
        if (phoneTMP) phoneTMP.text = string.IsNullOrWhiteSpace(data.phone) ? "�L" : data.phone;
        if (addressTMP) addressTMP.text = string.IsNullOrWhiteSpace(data.address) ? "�L" : data.address;

        // �ɯ���s
        if (navigateButton)
        {
            navigateButton.onClick.RemoveAllListeners();
            navigateButton.onClick.AddListener(() =>
            {
                // �H�g�n�׾ɯ�]��í�w�^
                var q = UnityWebRequest.EscapeURL($"{data.latitude},{data.longitude}");
                var url = $"https://www.google.com/maps/dir/?api=1&destination={q}";
                Application.OpenURL(url);
            });
        }

        // �����m�Ϥ�
        if (photoImage)
        {
            photoImage.sprite = noPhotoSprite;
            // ��ĳ�b Image �W���� Preserve Aspect
            // �ëO�� Image Type = Simple
        }

        // ���b�U���N������
        if (_photoCo != null) { StopCoroutine(_photoCo); _photoCo = null; }

        // 1) ���a Sprite�]�̰��u���^
        Sprite localSprite = data.photoSprite;
        if (localSprite == null && !string.IsNullOrWhiteSpace(data.photoPath))
        {
            // �Y CSV ���F Resources ���|�]�Ҧp Images/xxx�^�A�o��Ū��
            localSprite = Resources.Load<Sprite>(data.photoPath);
        }

        if (localSprite != null)
        {
            if (photoImage) photoImage.sprite = localSprite;
            return;
        }

        // 2) ���}�U���]�䴩������W�١^
        var url = !string.IsNullOrWhiteSpace(data.photoUrl) ? data.photoUrl :
                  !string.IsNullOrWhiteSpace(data.photo_url) ? data.photo_url : null;

        if (!string.IsNullOrWhiteSpace(url))
        {
            _photoCo = StartCoroutine(DownloadPhoto(url));
        }
        // �_�h�����w�]��
    }

    IEnumerator DownloadPhoto(string url)
    {
        _currentUrl = url;
        Debug.Log($"[POI][Photo] download start: {url}");

        using (var req = UnityWebRequestTexture.GetTexture(url))
        {
            req.timeout = 20; // �O�ɫO�@
            yield return req.SendWebRequest();

#if UNITY_2020_2_OR_NEWER
            if (req.result != UnityWebRequest.Result.Success)
#else
            if (req.isNetworkError || req.isHttpError)
#endif
            {
                Debug.LogWarning($"[POI][Photo] download failed: {req.error}\nURL: {url}");
                yield break;
            }

            var tex = DownloadHandlerTexture.GetContent(req);
            if (tex == null)
            {
                Debug.LogWarning($"[POI][Photo] texture null\nURL: {url}");
                yield break;
            }

            // �ন Sprite
            var rect = new Rect(0, 0, tex.width, tex.height);
            var pivot = new Vector2(0.5f, 0.5f);
            // 100 ����/���Y�i�]UI �Τ���@�ɤؤo�^
            var spr = Sprite.Create(tex, rect, pivot, 100f);

            if (photoImage)
            {
                photoImage.sprite = spr;
                // �Y�Ʊ�۰ʽվ�j�p�A�i�������ѤU��
                // photoImage.SetNativeSize();
            }

            Debug.Log($"[POI][Photo] download OK ({tex.width}x{tex.height})");
        }
        _photoCo = null;
    }
}
