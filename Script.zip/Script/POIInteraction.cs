using UnityEngine;
using UnityEngine.EventSystems;

[RequireComponent(typeof(Collider))] // 3D Collider
public class POIInteraction : MonoBehaviour, IPointerDownHandler
{
    private POIData data;
    private POIInfoPanel panel;

    void Awake()
    {
        data = GetComponent<POIData>();
        panel = FindObjectOfType<POIInfoPanel>(true);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        var topGO = eventData.pointerCurrentRaycast.gameObject;
        if (topGO != null && topGO != gameObject && topGO.transform.IsChildOf(transform) == false)
            return;

        if (panel != null && data != null)
        {
            panel.Show(data);
            eventData.Use();
        }
    }
}
