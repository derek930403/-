﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class back_to_menu : MonoBehaviour
{
    [SerializeField] public Button back_to_home;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public void Back_to_mainMenu()
    {
        SceneManager.LoadScene(0);
    }

}
