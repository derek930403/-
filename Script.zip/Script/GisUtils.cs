using UnityEngine;

public class GisUtils : MonoBehaviour
{
    public static GisUtils Instance;

    public Transform topLeftTransform;
    public Transform bottomRightTransform;

    private Vector2 topLeftLatLon;
    private Vector2 bottomRightLatLon;
    private Vector3 topLeftWorld;
    private Vector3 bottomRightWorld;

    void Awake()
    {
        Instance = this;

        topLeftLatLon = new Vector2(25.191270f, 121.423896f);      // �H���a�ϥ��W���g�n��
        bottomRightLatLon = new Vector2(25.148551f, 121.467560f);  // �H���a�ϥk�U���g�n��

        topLeftWorld = topLeftTransform.position;
        bottomRightWorld = bottomRightTransform.position;
    }

    public Vector3 LatLonToWorld(Vector2 latlon)
    {
        float xLerp = Mathf.InverseLerp(topLeftLatLon.y, bottomRightLatLon.y, latlon.y); // �g��
        float zLerp = Mathf.InverseLerp(topLeftLatLon.x, bottomRightLatLon.x, latlon.x); // �n��

        float worldX = Mathf.Lerp(topLeftWorld.x, bottomRightWorld.x, xLerp);
        float worldZ = Mathf.Lerp(topLeftWorld.z, bottomRightWorld.z, zLerp);

        return new Vector3(worldX, 0f, worldZ); // ���] y ���׬� 0
    }
}
