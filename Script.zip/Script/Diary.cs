﻿
/*//以下稱為uid版本
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using UnityEngine.SceneManagement;
using TMPro;
using System;

using UIButton = UnityEngine.UI.Button;
using UIImage = UnityEngine.UI.Image;
using UIRawImage = UnityEngine.UI.RawImage;

public class Diary : MonoBehaviour
{
    [Header("小日曆控制按鈕")]
    public UIButton calendarToggleButton;

    [Header("心情按鈕")]
    public UIButton mood_1, mood_2, mood_3, mood_4, mood_5;

    [Header("天氣按鈕")]
    public UIButton weather1, weather2, weather3;

    [Header("其他按鈕與元件")]
    public UIButton photo, back_to_menu, delete_all, viewDiaryButton;
    public UIRawImage displayImage;
    public TMP_InputField content, inputField;
    public TextMeshProUGUI date;
    public TMP_Text dateLabel;

    [Header("背景圖元件")]
    public UIImage weatherBackground;

    [Header("儲存提示元件")]
    public GameObject saveConfirmPanel;
    public UIImage sparkleImage;

    [Header("刪除確認視窗")]
    public GameObject deleteConfirmPanel;
    public UIButton deleteButton;
    public UIButton cancelButton;

    [Header("選擇照片提示按鈕")]
    public GameObject selectPhotoButton;

    [Header("小日曆元件")]
    public GameObject calendarPanel;
    public TMP_Text monthHeader;
    public Transform datesContainer;
    public List<UIButton> dateButtons = new();

    private string filePath => Path.Combine(Application.persistentDataPath, $"{GetCurrentUID()}_daily_texts.json");
    private System.DateTime currentDate;
    private System.DateTime currentMonth;
    private UIButton activeMoodButton = null;
    private UIButton activeWeatherButton = null;

    // 防抖控制
    private float saveDelay = 2f;
    private float lastEditTime = 0f;
    private bool needsSave = false;

    [System.Serializable]
    public class DailyData { public List<DateEntry> entries = new List<DateEntry>(); }

    [System.Serializable]
    public class DateEntry
    {
        public string date, text, imageBase64, mood, weather;
    }

    private Dictionary<string, string> dateTextMap = new();
    private Dictionary<string, string> imagePaths = new();
    private Dictionary<string, string> moodMap = new();
    private Dictionary<string, string> weatherMap = new();

    void Start()
    {
        string selectedDateFromDisplay = PlayerPrefs.GetString("SelectedDate", "");
        currentDate = System.DateTime.TryParse(selectedDateFromDisplay, out System.DateTime parsedDate) ? parsedDate : System.DateTime.Today;
        PlayerPrefs.DeleteKey("SelectedDate");

        currentMonth = currentDate;
        today_date();

        foreach (var btn in new[] { mood_1, mood_2, mood_3, mood_4, mood_5, weather1, weather2, weather3 })
            if (btn != null) btn.image.color = Color.white;

        LoadFromFile();

        if (inputField != null)
            inputField.onValueChanged.AddListener(OnInputFieldChanged);

        UpdateUI();
        ApplyGreetingPrefs();
        GenerateCalendar(currentMonth);

        if (viewDiaryButton != null)
            viewDiaryButton.onClick.AddListener(GoToDisplayPage);

        if (calendarToggleButton != null)
            calendarToggleButton.onClick.AddListener(() => { if (calendarPanel != null) calendarPanel.SetActive(!calendarPanel.activeSelf); });

        if (weatherBackground != null) weatherBackground.canvasRenderer.SetAlpha(1f);
        if (deleteButton != null) deleteButton.onClick.AddListener(ConfirmDeleteToday);
        if (cancelButton != null) cancelButton.onClick.AddListener(HideDeletePanel);
        if (deleteConfirmPanel != null) deleteConfirmPanel.SetActive(false);
        if (calendarPanel != null) calendarPanel.SetActive(false);

        if (FirebaseManager.Instance != null)
            FirebaseManager.Instance.auth.StateChanged += OnAuthStateChanged;
    }

    void Update()
    {
        if (needsSave && Time.time - lastEditTime > saveDelay)
        {
            SaveTodayText(false, false); // 防抖文字儲存，不儲存圖片
            needsSave = false;
        }
    }

    void OnDestroy()
    {
        if (FirebaseManager.Instance != null)
            FirebaseManager.Instance.auth.StateChanged -= OnAuthStateChanged;
    }

    void OnAuthStateChanged(object sender, System.EventArgs e)
    {
        LoadFromFile();
        UpdateUI();
    }

    private string GetCurrentUID()
    {
        if (FirebaseManager.Instance.user != null)
            return FirebaseManager.Instance.user.UserId;
        return "guest";
    }

    public void ToggleCalendar() { if (calendarPanel != null) calendarPanel.SetActive(!calendarPanel.activeSelf); }
    public void ShowCalendar() { if (calendarPanel != null) calendarPanel.SetActive(true); }
    public void HideCalendar() { if (calendarPanel != null) calendarPanel.SetActive(false); }

    public void PreviousMonth() { currentMonth = currentMonth.AddMonths(-1); GenerateCalendar(currentMonth); }
    public void NextMonth() { currentMonth = currentMonth.AddMonths(1); GenerateCalendar(currentMonth); }

    void GenerateCalendar(System.DateTime month)
    {
        var firstDay = new System.DateTime(month.Year, month.Month, 1);
        int startDayOfWeek = (int)firstDay.DayOfWeek;
        int daysInMonth = System.DateTime.DaysInMonth(month.Year, month.Month);

        if (monthHeader != null) monthHeader.text = month.ToString("MM");

        for (int i = 0; i < dateButtons.Count; i++)
        {
            TMP_Text btnText = dateButtons[i].GetComponentInChildren<TMP_Text>();
            if (btnText != null) btnText.text = "";
            dateButtons[i].interactable = false;
            dateButtons[i].onClick.RemoveAllListeners();

            var btnImage = dateButtons[i].GetComponent<UIImage>();
            if (btnImage != null) btnImage.color = Color.white;
        }

        for (int i = 0; i < daysInMonth; i++)
        {
            int btnIndex = startDayOfWeek + i;
            if (btnIndex >= dateButtons.Count) continue;

            TMP_Text btnText = dateButtons[btnIndex].GetComponentInChildren<TMP_Text>();
            int day = i + 1;
            if (btnText != null) btnText.text = day.ToString();
            dateButtons[btnIndex].interactable = true;

            var thisDate = new System.DateTime(month.Year, month.Month, day);
            string key = thisDate.ToString("yyyy-MM-dd");

            var btnImg = dateButtons[btnIndex].GetComponent<UIImage>();
            if (thisDate.Date == System.DateTime.Today.Date)
            {
                if (btnImg != null) btnImg.color = new Color(1f, 0.7f, 0.7f);
            }
            else if (HasAnyContent(key))
            {
                if (btnImg != null) btnImg.color = new Color(0.7f, 0.8f, 1f);
            }

            dateButtons[btnIndex].onClick.AddListener(() =>
            {
                currentDate = thisDate;
                if (dateLabel != null) dateLabel.text = currentDate.ToString("yyyy-MM-dd");
                UpdateUI();
                if (calendarPanel != null) calendarPanel.SetActive(false);
            });
        }
    }

    private bool HasAnyContent(string key)
    {
        return (dateTextMap.ContainsKey(key) && !string.IsNullOrEmpty(dateTextMap[key])) ||
               (imagePaths.ContainsKey(key) && !string.IsNullOrEmpty(imagePaths[key])) ||
               (moodMap.ContainsKey(key)) ||
               (weatherMap.ContainsKey(key));
    }

    void ApplyGreetingPrefs()
    {
        string key = currentDate.ToString("yyyy-MM-dd");
        string moodFromGreeting = PlayerPrefs.GetString("SelectedMood", "");
        string weatherFromGreeting = PlayerPrefs.GetString("SelectedWeather", "");

        if (!string.IsNullOrEmpty(moodFromGreeting))
        {
            foreach (var m in new[] { mood_1, mood_2, mood_3, mood_4, mood_5 })
                if (m != null && m.name == moodFromGreeting) { mood(m); break; }
            PlayerPrefs.DeleteKey("SelectedMood");
        }
        if (!string.IsNullOrEmpty(weatherFromGreeting))
        {
            foreach (var w in new[] { weather1, weather2, weather3 })
                if (w != null && w.name == weatherFromGreeting) { weather(w); break; }
            PlayerPrefs.DeleteKey("SelectedWeather");
        }
        if (!string.IsNullOrEmpty(moodFromGreeting) || !string.IsNullOrEmpty(weatherFromGreeting))
        {
            SaveTodayText();
            UpdateUI();
        }
    }

    public void ShowDeletePanel() => deleteConfirmPanel?.SetActive(true);
    public void HideDeletePanel() => deleteConfirmPanel?.SetActive(false);
    public void ConfirmDeleteToday() { DeleteTodayEntry(); HideDeletePanel(); }

    public void mood(UIButton clicked)
    {
        string key = currentDate.ToString("yyyy-MM-dd");
        var moods = new[] { mood_1, mood_2, mood_3, mood_4, mood_5 };
        if (activeMoodButton == clicked)
        {
            foreach (var m in moods) if (m != null) m.image.color = Color.white;
            activeMoodButton = null; moodMap.Remove(key);
        }
        else
        {
            foreach (var m in moods) if (m != null) m.image.color = Color.gray;
            if (clicked != null) clicked.image.color = Color.white;
            activeMoodButton = clicked; moodMap[key] = clicked != null ? clicked.name : null;
        }
        SaveTodayText(false, false);
    }

    public void weather(UIButton clicked)
    {
        string key = currentDate.ToString("yyyy-MM-dd");
        var weathers = new[] { weather1, weather2, weather3 };
        if (activeWeatherButton == clicked)
        {
            foreach (var w in weathers) if (w != null) w.image.color = Color.white;
            activeWeatherButton = null; weatherMap.Remove(key);
        }
        else
        {
            foreach (var w in weathers) if (w != null) w.image.color = Color.gray;
            if (clicked != null) clicked.image.color = Color.white;
            activeWeatherButton = clicked; weatherMap[key] = clicked != null ? clicked.name : null;
        }
        UpdateUI();
        SaveTodayText(false, false);
    }

    public void today_date() { if (date != null) date.text = System.DateTime.Now.ToString("yyyy-MM-dd"); }

    public void Back_to_mainMenu()
    {
        SaveTodayText(true);
        SceneManager.LoadScene(0);
    }

    public void GoToDisplayPage()
    {
        SaveTodayText(true);
        PlayerPrefs.SetString("SelectedDate", currentDate.ToString("yyyy-MM-dd"));
        PlayerPrefs.SetString("ReloadDisplay", "true");
        SceneManager.LoadScene("DiaryDisplayScene");
    }

    public void OnInputFieldChanged(string text)
    {
        lastEditTime = Time.time;
        needsSave = true;
    }

public void PickImage()
{
    NativeGallery.GetImageFromGallery((path) => {
        if (path != null)
        {
            Texture2D loadedTexture = NativeGallery.LoadImageAtPath(path, 1024);
            if (loadedTexture != null && displayImage != null)
            {
                // 轉成可讀取的 Texture2D
                Texture2D readableTex = MakeTextureReadable(loadedTexture);

                displayImage.texture = readableTex;
                FitRawImageToFrame(displayImage);

                if (selectPhotoButton != null)
                    selectPhotoButton.SetActive(false);

                SaveTodayText(false, true); // 圖片一定儲存

                // 釋放原本的 loadedTexture（避免浪費記憶體）
                UnityEngine.Object.Destroy(loadedTexture);
            }
        }
    }, "選擇一張日記照片");
}

// 把任何 Texture 轉成可讀 Texture2D
Texture2D MakeTextureReadable(Texture source)
{
    Texture2D readableTex = new Texture2D(source.width, source.height, TextureFormat.RGBA32, false);
    RenderTexture rt = RenderTexture.GetTemporary(source.width, source.height, 0);
    Graphics.Blit(source, rt);
    RenderTexture.active = rt;
    readableTex.ReadPixels(new Rect(0, 0, rt.width, rt.height), 0, 0);
    readableTex.Apply();
    RenderTexture.active = null;
    RenderTexture.ReleaseTemporary(rt);
    return readableTex;
}

public void SaveTodayText(bool showSaveEffect = true, bool saveImage = true)
{
    string key = currentDate.ToString("yyyy-MM-dd");
    if (inputField != null) dateTextMap[key] = inputField.text;

    if (saveImage && displayImage != null && displayImage.texture != null)
    {
        // 確保 texture 可讀
        Texture2D tex = MakeTextureReadable(displayImage.texture);
        if (tex != null)
        {
            byte[] bytes = tex.EncodeToPNG();
            string base64 = Convert.ToBase64String(bytes);
            imagePaths[key] = base64;
            UnityEngine.Object.Destroy(tex); // 釋放內存
        }
    }

    SaveToFile();

    if (showSaveEffect && saveConfirmPanel != null && sparkleImage != null)
        StartCoroutine(ShowSaveConfirmWithSparkle());

    GenerateCalendar(currentMonth);

    UploadDiaryToFirebase(key);
}


    IEnumerator ShowSaveConfirmWithSparkle()
    {
        saveConfirmPanel.SetActive(true); sparkleImage.gameObject.SetActive(true);
        for (int i = 0; i < 2; i++)
        {
            sparkleImage.color = new Color(1, 1, 1, 1);
            yield return new WaitForSeconds(0.2f);
            sparkleImage.color = new Color(1, 1, 1, 0);
            yield return new WaitForSeconds(0.2f);
        }
        saveConfirmPanel.SetActive(false); sparkleImage.gameObject.SetActive(false);
    }

void UploadDiaryToFirebase(string dateKey)
{
    if (FirebaseManager.Instance == null || FirebaseManager.Instance.user == null)
    {
        Debug.LogError("請先登入 Firebase！");
        return;
    }

    string uid = FirebaseManager.Instance.user.UserId;
    string email = FirebaseManager.Instance.user.Email; // 取得使用者 Email
    string timestamp = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); // 精確到秒

    Dictionary<string, object> diaryData = new Dictionary<string, object>
    {
        {"uid", uid },
        {"email", email }, // 新增 Email 欄位
        {"timestamp", timestamp },
        {"date", dateKey },
        {"text", dateTextMap.ContainsKey(dateKey) ? dateTextMap[dateKey] : "" },
        {"mood", moodMap.ContainsKey(dateKey) ? moodMap[dateKey] : "" },
        {"weather", weatherMap.ContainsKey(dateKey) ? weatherMap[dateKey] : "" },
        {"imageBase64", imagePaths.ContainsKey(dateKey) ? imagePaths[dateKey] : "" }
    };

    FirebaseManager.Instance.SaveDiaryData(diaryData);
}


    void UpdateUI()
    {
        string key = currentDate.ToString("yyyy-MM-dd");
        if (dateLabel != null) dateLabel.text = key;
        if (inputField != null) inputField.text = dateTextMap.ContainsKey(key) ? dateTextMap[key] : "";

        if (displayImage != null && displayImage.texture != null)
        {
            UnityEngine.Object.Destroy(displayImage.texture);
            displayImage.texture = null;
        }

        bool hasImage = imagePaths.ContainsKey(key) && !string.IsNullOrEmpty(imagePaths[key]);
        if (hasImage)
        {
            byte[] bytes = Convert.FromBase64String(imagePaths[key]);
            Texture2D texture = new Texture2D(2, 2);
            texture.LoadImage(bytes);
            displayImage.texture = texture;
            FitRawImageToFrame(displayImage);
        }
        else if (displayImage != null)
        {
            displayImage.texture = null;
            displayImage.rectTransform.sizeDelta = new Vector2(200f, 200f);
            displayImage.rectTransform.anchoredPosition = Vector2.zero;
        }

        if (selectPhotoButton != null)
            selectPhotoButton.SetActive(!hasImage);

        activeMoodButton = null;
        activeWeatherButton = null;

        foreach (var m in new[] { mood_1, mood_2, mood_3, mood_4, mood_5 })
            if (m != null && moodMap.ContainsKey(key) && m.name == moodMap[key])
                activeMoodButton = m;

        foreach (var w in new[] { weather1, weather2, weather3 })
            if (w != null && weatherMap.ContainsKey(key) && w.name == weatherMap[key])
                activeWeatherButton = w;

        foreach (var m in new[] { mood_1, mood_2, mood_3, mood_4, mood_5 })
            if (m != null) m.image.color = (m == activeMoodButton) ? Color.white : Color.gray;

        foreach (var w in new[] { weather1, weather2, weather3 })
            if (w != null) w.image.color = (w == activeWeatherButton) ? Color.white : Color.gray;
    }

    void FitRawImageToFrame(UIRawImage rawImage)
    {
        if (rawImage == null || rawImage.texture == null) return;
        float frameWidth = rawImage.rectTransform.rect.width;
        float frameHeight = rawImage.rectTransform.rect.height;
        float imageWidth = rawImage.texture.width;
        float imageHeight = rawImage.texture.height;
        float scale = Math.Min(frameWidth / imageWidth, frameHeight / imageHeight);
        rawImage.rectTransform.sizeDelta = new Vector2(imageWidth * scale, imageHeight * scale);
        rawImage.rectTransform.anchoredPosition = Vector2.zero;
    }

    void SaveToFile()
    {
        DailyData data = new DailyData();
        foreach (var kv in dateTextMap)
        {
            data.entries.Add(new DateEntry
            {
                date = kv.Key,
                text = kv.Value,
                imageBase64 = imagePaths.ContainsKey(kv.Key) ? imagePaths[kv.Key] : "",
                mood = moodMap.ContainsKey(kv.Key) ? moodMap[kv.Key] : "",
                weather = weatherMap.ContainsKey(kv.Key) ? weatherMap[kv.Key] : ""
            });
        }

        File.WriteAllText(filePath, JsonUtility.ToJson(data));
    }

    void LoadFromFile()
    {
        dateTextMap.Clear();
        imagePaths.Clear();
        moodMap.Clear();
        weatherMap.Clear();

        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            DailyData data = JsonUtility.FromJson<DailyData>(json);
            if (data != null && data.entries != null)
            {
                foreach (var entry in data.entries)
                {
                    dateTextMap[entry.date] = entry.text;
                    if (!string.IsNullOrEmpty(entry.imageBase64))
                        imagePaths[entry.date] = entry.imageBase64;
                    if (!string.IsNullOrEmpty(entry.mood))
                        moodMap[entry.date] = entry.mood;
                    if (!string.IsNullOrEmpty(entry.weather))
                        weatherMap[entry.date] = entry.weather;
                }
            }
        }
    }

void DeleteTodayEntry()
{
    string key = currentDate.ToString("yyyy-MM-dd");

    // 移除今天的資料
    dateTextMap.Remove(key);
    imagePaths.Remove(key);
    moodMap.Remove(key);
    weatherMap.Remove(key);

    // 更新 JSON 檔
    SaveToFile(); // 注意這裡只會更新對應 UID 的檔案

    // 更新畫面
    UpdateUI();


}

}*/
// 以下稱為uid版本
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using UnityEngine.SceneManagement;
using TMPro;
using System;

using UIButton = UnityEngine.UI.Button;
using UIImage = UnityEngine.UI.Image;
using UIRawImage = UnityEngine.UI.RawImage;

public class Diary : MonoBehaviour
{
    [Header("小日曆控制按鈕")]
    public UIButton calendarToggleButton;

    [Header("心情按鈕")]
    public UIButton mood_1, mood_2, mood_3, mood_4, mood_5;

    [Header("天氣按鈕")]
    public UIButton weather1, weather2, weather3;

    [Header("其他按鈕與元件")]
    public UIButton photo, back_to_menu, delete_all, viewDiaryButton;
    public UIRawImage displayImage;
    public TMP_InputField content, inputField;
    public TextMeshProUGUI date;
    public TMP_Text dateLabel;
    public Button prevButton;
    public Button nextButton;

    [Header("背景圖元件")]
    public UIImage weatherBackground;

    [Header("儲存提示元件")]
    public GameObject saveConfirmPanel;
    public UIImage sparkleImage;

    [Header("刪除確認視窗")]
    public GameObject deleteConfirmPanel;
    public UIButton deleteButton;
    public UIButton cancelButton;

    [Header("選擇照片提示按鈕")]
    public GameObject selectPhotoButton;

    [Header("小日曆元件")]
    public GameObject calendarPanel;
    public TMP_Text monthHeader;
    public Transform datesContainer;
    public List<UIButton> dateButtons = new();

    // === 追加：UID 快取與 PlayerPrefs Key ===
    private string _cachedUID;
    private const string kUidPrefs = "UID";

    private string filePath => Path.Combine(Application.persistentDataPath, $"{GetCurrentUID()}_daily_texts.json");
    private System.DateTime currentDate;
    private System.DateTime currentMonth;
    private UIButton activeMoodButton = null;
    private UIButton activeWeatherButton = null;

    // 防抖控制
    private float saveDelay = 2f;
    private float lastEditTime = 0f;
    private bool needsSave = false;

    [System.Serializable]
    public class DailyData { public List<DateEntry> entries = new List<DateEntry>(); }

    [System.Serializable]
    public class DateEntry
    {
        public string date, text, imageBase64, mood, weather;
    }

    private Dictionary<string, string> dateTextMap = new();
    private Dictionary<string, string> imagePaths = new();
    private Dictionary<string, string> moodMap = new();
    private Dictionary<string, string> weatherMap = new();

    void Start()
    {
        // 先暖機 UID（第一次會寫回 PlayerPrefs，避免後面路徑取用時才初始化）
        _ = GetCurrentUID();

        string selectedDateFromDisplay = PlayerPrefs.GetString("SelectedDate", "");
        currentDate = System.DateTime.TryParse(selectedDateFromDisplay, out System.DateTime parsedDate) ? parsedDate : System.DateTime.Today;
        PlayerPrefs.DeleteKey("SelectedDate");

        currentMonth = currentDate;
        today_date();

        foreach (var btn in new[] { mood_1, mood_2, mood_3, mood_4, mood_5, weather1, weather2, weather3 })
            if (btn != null) btn.image.color = Color.white;

        LoadFromFile();

        if (inputField != null)
            inputField.onValueChanged.AddListener(OnInputFieldChanged);

        UpdateUI();
        ApplyGreetingPrefs();
        GenerateCalendar(currentMonth);

        if (viewDiaryButton != null)
            viewDiaryButton.onClick.AddListener(GoToDisplayPage);

        if (calendarToggleButton != null)
            calendarToggleButton.onClick.AddListener(() => { if (calendarPanel != null) calendarPanel.SetActive(!calendarPanel.activeSelf); });

        if (weatherBackground != null) weatherBackground.canvasRenderer.SetAlpha(1f);
        if (deleteButton != null) deleteButton.onClick.AddListener(ConfirmDeleteToday);
        if (cancelButton != null) cancelButton.onClick.AddListener(HideDeletePanel);
        if (deleteConfirmPanel != null) deleteConfirmPanel.SetActive(false);
        if (calendarPanel != null) calendarPanel.SetActive(false);

        // ✅ 訂閱前加強保險
        if (FirebaseManager.Instance != null && FirebaseManager.Instance.auth != null)
            FirebaseManager.Instance.auth.StateChanged += OnAuthStateChanged;
    }

    void Update()
    {
        if (needsSave && Time.time - lastEditTime > saveDelay)
        {
            SaveTodayText(false, false); // 防抖文字儲存，不儲存圖片
            needsSave = false;
        }
    }

    void OnDestroy()
    {
        if (FirebaseManager.Instance != null && FirebaseManager.Instance.auth != null)
            FirebaseManager.Instance.auth.StateChanged -= OnAuthStateChanged;
    }

    void OnAuthStateChanged(object sender, System.EventArgs e)
    {
        LoadFromFile();
        UpdateUI();
    }

    // ✅ 安全 UID 取得（Firebase → PlayerPrefs → 裝置ID/GUID），含快取
    private string GetCurrentUID()
    {
        if (!string.IsNullOrEmpty(_cachedUID))
            return _cachedUID;

        var fm = FirebaseManager.Instance;
        if (fm != null && fm.user != null && !string.IsNullOrEmpty(fm.user.UserId))
            _cachedUID = fm.user.UserId;

        if (string.IsNullOrEmpty(_cachedUID))
            _cachedUID = PlayerPrefs.GetString(kUidPrefs, string.Empty);

        if (string.IsNullOrEmpty(_cachedUID))
            _cachedUID = string.IsNullOrEmpty(SystemInfo.deviceUniqueIdentifier)
                ? System.Guid.NewGuid().ToString("N")
                : SystemInfo.deviceUniqueIdentifier;

        PlayerPrefs.SetString(kUidPrefs, _cachedUID);
        PlayerPrefs.Save();
        return _cachedUID;
    }

    public void ToggleCalendar() { if (calendarPanel != null) calendarPanel.SetActive(!calendarPanel.activeSelf); }
    public void ShowCalendar() { if (calendarPanel != null) calendarPanel.SetActive(true); }
    public void HideCalendar() { if (calendarPanel != null) calendarPanel.SetActive(false); }

    public void PreviousMonth() { currentMonth = currentMonth.AddMonths(-1); GenerateCalendar(currentMonth); }
    public void NextMonth() { currentMonth = currentMonth.AddMonths(1); GenerateCalendar(currentMonth); }

    void GenerateCalendar(System.DateTime month)
    {
        var firstDay = new System.DateTime(month.Year, month.Month, 1);
        int startDayOfWeek = (int)firstDay.DayOfWeek;
        int daysInMonth = System.DateTime.DaysInMonth(month.Year, month.Month);

        if (monthHeader != null) monthHeader.text = month.ToString("MM");

        for (int i = 0; i < dateButtons.Count; i++)
        {
            TMP_Text btnText = dateButtons[i].GetComponentInChildren<TMP_Text>();
            if (btnText != null) btnText.text = "";
            dateButtons[i].interactable = false;
            dateButtons[i].onClick.RemoveAllListeners();

            var btnImage = dateButtons[i].GetComponent<UIImage>();
            if (btnImage != null) btnImage.color = Color.white;
        }

        for (int i = 0; i < daysInMonth; i++)
        {
            int btnIndex = startDayOfWeek + i;
            if (btnIndex >= dateButtons.Count) continue;

            TMP_Text btnText = dateButtons[btnIndex].GetComponentInChildren<TMP_Text>();
            int day = i + 1;
            if (btnText != null) btnText.text = day.ToString();
            dateButtons[btnIndex].interactable = true;

            var thisDate = new System.DateTime(month.Year, month.Month, day);
            string key = thisDate.ToString("yyyy-MM-dd");

            var btnImg = dateButtons[btnIndex].GetComponent<UIImage>();
            if (thisDate.Date == System.DateTime.Today.Date)
            {
                if (btnImg != null) btnImg.color = new Color(1f, 0.7f, 0.7f);
            }
            else if (HasAnyContent(key))
            {
                if (btnImg != null) btnImg.color = new Color(0.7f, 0.8f, 1f);
            }

            dateButtons[btnIndex].onClick.AddListener(() =>
            {
                currentDate = thisDate;
                if (dateLabel != null) dateLabel.text = currentDate.ToString("yyyy-MM-dd");
                UpdateUI();
                if (calendarPanel != null) calendarPanel.SetActive(false);
            });
        }
    }

    private bool HasAnyContent(string key)
    {
        return (dateTextMap.ContainsKey(key) && !string.IsNullOrEmpty(dateTextMap[key])) ||
               (imagePaths.ContainsKey(key) && !string.IsNullOrEmpty(imagePaths[key])) ||
               (moodMap.ContainsKey(key)) ||
               (weatherMap.ContainsKey(key));
    }

    void ApplyGreetingPrefs()
    {
        string key = currentDate.ToString("yyyy-MM-dd");
        string moodFromGreeting = PlayerPrefs.GetString("SelectedMood", "");
        string weatherFromGreeting = PlayerPrefs.GetString("SelectedWeather", "");

        if (!string.IsNullOrEmpty(moodFromGreeting))
        {
            foreach (var m in new[] { mood_1, mood_2, mood_3, mood_4, mood_5 })
                if (m != null && m.name == moodFromGreeting) { mood(m); break; }
            PlayerPrefs.DeleteKey("SelectedMood");
        }
        if (!string.IsNullOrEmpty(weatherFromGreeting))
        {
            foreach (var w in new[] { weather1, weather2, weather3 })
                if (w != null && w.name == weatherFromGreeting) { weather(w); break; }
            PlayerPrefs.DeleteKey("SelectedWeather");
        }
        if (!string.IsNullOrEmpty(moodFromGreeting) || !string.IsNullOrEmpty(weatherFromGreeting))
        {
            SaveTodayText();
            UpdateUI();
        }
    }

    public void ShowDeletePanel() => deleteConfirmPanel?.SetActive(true);
    public void HideDeletePanel() => deleteConfirmPanel?.SetActive(false);
    public void ConfirmDeleteToday() { DeleteTodayEntry(); HideDeletePanel(); }

    public void mood(UIButton clicked)
    {
        string key = currentDate.ToString("yyyy-MM-dd");
        var moods = new[] { mood_1, mood_2, mood_3, mood_4, mood_5 };
        if (activeMoodButton == clicked)
        {
            foreach (var m in moods) if (m != null) m.image.color = Color.white;
            activeMoodButton = null; moodMap.Remove(key);
        }
        else
        {
            foreach (var m in moods) if (m != null) m.image.color = Color.gray;
            if (clicked != null) clicked.image.color = Color.white;
            activeMoodButton = clicked; moodMap[key] = clicked != null ? clicked.name : null;
        }
        SaveTodayText(false, false);
    }

    public void weather(UIButton clicked)
    {
        string key = currentDate.ToString("yyyy-MM-dd");
        var weathers = new[] { weather1, weather2, weather3 };
        if (activeWeatherButton == clicked)
        {
            foreach (var w in weathers) if (w != null) w.image.color = Color.white;
            activeWeatherButton = null; weatherMap.Remove(key);
        }
        else
        {
            foreach (var w in weathers) if (w != null) w.image.color = Color.gray;
            if (clicked != null) clicked.image.color = Color.white;
            activeWeatherButton = clicked; weatherMap[key] = clicked != null ? clicked.name : null;
        }
        UpdateUI();
        SaveTodayText(false, false);
    }

    public void today_date() { if (date != null) date.text = System.DateTime.Now.ToString("yyyy-MM-dd"); }

    public void Back_to_mainMenu()
    {
        SaveTodayText(true);
        SceneManager.LoadScene(0);
    }

    public void GoToDisplayPage()
    {
        SaveTodayText(true);
        PlayerPrefs.SetString("SelectedDate", currentDate.ToString("yyyy-MM-dd"));
        PlayerPrefs.SetString("ReloadDisplay", "true");
        SceneManager.LoadScene("DiaryDisplayScene");
    }

    public void OnInputFieldChanged(string text)
    {
        lastEditTime = Time.time;
        needsSave = true;
    }

    public void PickImage()
    {
        NativeGallery.GetImageFromGallery((path) => {
            if (path != null)
            {
                Texture2D loadedTexture = NativeGallery.LoadImageAtPath(path, 1024);
                if (loadedTexture != null && displayImage != null)
                {
                    // 轉成可讀取的 Texture2D
                    Texture2D readableTex = MakeTextureReadable(loadedTexture);

                    displayImage.texture = readableTex;
                    FitRawImageToFrame(displayImage);

                    if (selectPhotoButton != null)
                        selectPhotoButton.SetActive(false);

                    SaveTodayText(false, true); // 圖片一定儲存

                    // 釋放原本的 loadedTexture（避免浪費記憶體）
                    UnityEngine.Object.Destroy(loadedTexture);
                }
            }
        }, "選擇一張日記照片");
    }

    // 把任何 Texture 轉成可讀 Texture2D
    Texture2D MakeTextureReadable(Texture source)
    {
        Texture2D readableTex = new Texture2D(source.width, source.height, TextureFormat.RGBA32, false);
        RenderTexture rt = RenderTexture.GetTemporary(source.width, source.height, 0);
        Graphics.Blit(source, rt);
        RenderTexture.active = rt;
        readableTex.ReadPixels(new Rect(0, 0, rt.width, rt.height), 0, 0);
        readableTex.Apply();
        RenderTexture.active = null;
        RenderTexture.ReleaseTemporary(rt);
        return readableTex;
    }

    public void SaveTodayText(bool showSaveEffect = true, bool saveImage = true)
    {
        string key = currentDate.ToString("yyyy-MM-dd");
        if (inputField != null) dateTextMap[key] = inputField.text;

        if (saveImage && displayImage != null && displayImage.texture != null)
        {
            // 確保 texture 可讀
            Texture2D tex = MakeTextureReadable(displayImage.texture);
            if (tex != null)
            {
                byte[] bytes = tex.EncodeToPNG();
                string base64 = Convert.ToBase64String(bytes);
                imagePaths[key] = base64;
                UnityEngine.Object.Destroy(tex); // 釋放內存
            }
        }

        SaveToFile();

        if (showSaveEffect && saveConfirmPanel != null && sparkleImage != null)
            StartCoroutine(ShowSaveConfirmWithSparkle());

        GenerateCalendar(currentMonth);

        UploadDiaryToFirebase(key);
    }

    IEnumerator ShowSaveConfirmWithSparkle()
    {
        saveConfirmPanel.SetActive(true); sparkleImage.gameObject.SetActive(true);
        for (int i = 0; i < 2; i++)
        {
            sparkleImage.color = new Color(1, 1, 1, 1);
            yield return new WaitForSeconds(0.2f);
            sparkleImage.color = new Color(1, 1, 1, 0);
            yield return new WaitForSeconds(0.2f);
        }
        saveConfirmPanel.SetActive(false); sparkleImage.gameObject.SetActive(false);
    }

    void UploadDiaryToFirebase(string dateKey)
    {
        if (FirebaseManager.Instance == null || FirebaseManager.Instance.user == null)
        {
            Debug.LogError("請先登入 Firebase！");
            return;
        }

        string uid = FirebaseManager.Instance.user.UserId;
        string email = FirebaseManager.Instance.user.Email; // 取得使用者 Email
        string timestamp = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); // 精確到秒

        Dictionary<string, object> diaryData = new Dictionary<string, object>
        {
            {"uid", uid },
            {"email", email }, // 新增 Email 欄位
            {"timestamp", timestamp },
            {"date", dateKey },
            {"text", dateTextMap.ContainsKey(dateKey) ? dateTextMap[dateKey] : "" },
            {"mood", moodMap.ContainsKey(dateKey) ? moodMap[dateKey] : "" },
            {"weather", weatherMap.ContainsKey(dateKey) ? weatherMap[dateKey] : "" },
            {"imageBase64", imagePaths.ContainsKey(dateKey) ? imagePaths[dateKey] : "" }
        };

        FirebaseManager.Instance.SaveDiaryData(diaryData);
    }

    void UpdateUI()
    {
        string key = currentDate.ToString("yyyy-MM-dd");
        if (dateLabel != null) dateLabel.text = key;
        if (inputField != null) inputField.text = dateTextMap.ContainsKey(key) ? dateTextMap[key] : "";

        if (displayImage != null && displayImage.texture != null)
        {
            UnityEngine.Object.Destroy(displayImage.texture);
            displayImage.texture = null;
        }

        bool hasImage = imagePaths.ContainsKey(key) && !string.IsNullOrEmpty(imagePaths[key]);
        if (hasImage)
        {
            byte[] bytes = Convert.FromBase64String(imagePaths[key]);
            Texture2D texture = new Texture2D(2, 2);
            texture.LoadImage(bytes);
            displayImage.texture = texture;
            FitRawImageToFrame(displayImage);
        }
        else if (displayImage != null)
        {
            displayImage.texture = null;
            displayImage.rectTransform.sizeDelta = new Vector2(200f, 200f);
            displayImage.rectTransform.anchoredPosition = Vector2.zero;
        }

        if (selectPhotoButton != null)
            selectPhotoButton.SetActive(!hasImage);

        activeMoodButton = null;
        activeWeatherButton = null;

        foreach (var m in new[] { mood_1, mood_2, mood_3, mood_4, mood_5 })
            if (m != null && moodMap.ContainsKey(key) && m.name == moodMap[key])
                activeMoodButton = m;

        foreach (var w in new[] { weather1, weather2, weather3 })
            if (w != null && weatherMap.ContainsKey(key) && w.name == weatherMap[key])
                activeWeatherButton = w;

        foreach (var m in new[] { mood_1, mood_2, mood_3, mood_4, mood_5 })
            if (m != null) m.image.color = (m == activeMoodButton) ? Color.white : Color.gray;

        foreach (var w in new[] { weather1, weather2, weather3 })
            if (w != null) w.image.color = (w == activeWeatherButton) ? Color.white : Color.gray;
    }

    void FitRawImageToFrame(UIRawImage rawImage)
    {
        if (rawImage == null || rawImage.texture == null) return;
        float frameWidth = rawImage.rectTransform.rect.width;
        float frameHeight = rawImage.rectTransform.rect.height;
        float imageWidth = rawImage.texture.width;
        float imageHeight = rawImage.texture.height;
        float scale = Math.Min(frameWidth / imageWidth, frameHeight / imageHeight);
        rawImage.rectTransform.sizeDelta = new Vector2(imageWidth * scale, imageHeight * scale);
        rawImage.rectTransform.anchoredPosition = Vector2.zero;
    }

    // ✅ try/catch 版存檔
    void SaveToFile()
    {
        DailyData data = new DailyData();
        foreach (var kv in dateTextMap)
        {
            data.entries.Add(new DateEntry
            {
                date = kv.Key,
                text = kv.Value,
                imageBase64 = imagePaths.ContainsKey(kv.Key) ? imagePaths[kv.Key] : "",
                mood = moodMap.ContainsKey(kv.Key) ? moodMap[kv.Key] : "",
                weather = weatherMap.ContainsKey(kv.Key) ? weatherMap[kv.Key] : ""
            });
        }

        try
        {
            File.WriteAllText(filePath, JsonUtility.ToJson(data));
        }
        catch (Exception ex)
        {
            Debug.LogError($"[Diary] SaveToFile 失敗：{ex.Message}\nPath={filePath}", this);
        }
    }

    // ✅ try/catch 版讀檔
    void LoadFromFile()
    {
        dateTextMap.Clear();
        imagePaths.Clear();
        moodMap.Clear();
        weatherMap.Clear();

        try
        {
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                if (!string.IsNullOrEmpty(json))
                {
                    DailyData data = JsonUtility.FromJson<DailyData>(json);
                    if (data != null && data.entries != null)
                    {
                        foreach (var entry in data.entries)
                        {
                            dateTextMap[entry.date] = entry.text;
                            if (!string.IsNullOrEmpty(entry.imageBase64))
                                imagePaths[entry.date] = entry.imageBase64;
                            if (!string.IsNullOrEmpty(entry.mood))
                                moodMap[entry.date] = entry.mood;
                            if (!string.IsNullOrEmpty(entry.weather))
                                weatherMap[entry.date] = entry.weather;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"[Diary] LoadFromFile 失敗：{ex.Message}\nPath={filePath}", this);
        }
    }

    void DeleteTodayEntry()
    {
        string key = currentDate.ToString("yyyy-MM-dd");

        // 移除今天的資料
        dateTextMap.Remove(key);
        imagePaths.Remove(key);
        moodMap.Remove(key);
        weatherMap.Remove(key);

        // 更新 JSON 檔
        SaveToFile(); // 注意這裡只會更新對應 UID 的檔案

        // 更新畫面
        UpdateUI();
    }
}
