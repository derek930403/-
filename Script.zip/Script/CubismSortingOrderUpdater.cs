﻿using UnityEngine;
using Live2D.Cubism.Core;
using Live2D.Cubism.Rendering;

namespace Live2D.Cubism.Rendering
{
    [ExecuteAlways]
    [RequireComponent(typeof(CubismModel))]
    public class CubismSortingOrderUpdater : MonoBehaviour
    {
        public string sortingLayerName = "Character";
        public int baseOrderInLayer = 100;

        private void LateUpdate()
        {
            var drawables = GetComponentsInChildren<CubismDrawable>(true);

            for (int i = 0; i < drawables.Length; i++)
            {
                var d = drawables[i];
                var renderer = d.GetComponent<Renderer>();
                var cubismRenderer = d.GetComponent<CubismRenderer>();

                if (renderer != null && cubismRenderer != null)
                {
                    renderer.sortingLayerName = sortingLayerName;

                    // ✅ 正確方式：透過 CubismRenderer.LocalSortingOrder 來調整順序
                    cubismRenderer.LocalSortingOrder = i;

                    // ✅ 根據需要，也可直接設 order（若不使用 CubismRenderController 控制）
                    renderer.sortingOrder = baseOrderInLayer + i;
                }
            }
        }
    }
}


