// WhereAmIWithAddress.cs
// 使用 Mapbox 定位與逆向地理編碼 (Action<ReverseGeocodeResponse>) 顯示地址
// 支援 Editor 模擬 / Android 權限請求 / UI 顯示

using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Mapbox.Unity.Map;
using Mapbox.Utils;
using Mapbox.Unity;
using Mapbox.Geocoding;

public class WhereAmIWithAddress : MonoBehaviour
{
    [Header("==== 地圖 & 定位 ====")]
    [Tooltip("請綁定 Mapbox AbstractMap 元件")]
    public AbstractMap map;
    [Tooltip("定位圖釘 Prefab（可以是小標記物件）")]
    public GameObject pinPrefab;
    [Tooltip("圖釘往上偏移量")]
    public float pinYOffset = 10f;

    [Tooltip("是否自動將地圖中心移到定位點")]
    public bool centerMapOnLocate = true;
    [Range(3, 20)]
    public float centerZoom = 15f;

    [Header("==== UI 設定 ====")]
    [Tooltip("『我在哪裡』按鈕，點擊會呼叫 OnClickWhereAmI")]
    public Button whereAmIButton;
    [Tooltip("載入中提示 (CanvasGroup)，可控制顯示/隱藏")]
    public CanvasGroup loadingHint;

    [Header("==== 地址顯示 ====")]
    [Tooltip("地址面板 (CanvasGroup)，建議 alpha 預設 0")]
    public CanvasGroup addressPanel;
    [Tooltip("顯示地址的 TMP_Text")]
    public TMP_Text addressText;
    [Tooltip("定位後是否自動顯示地址面板")]
    public bool autoShowAddress = true;
    [Tooltip("地址面板淡入淡出時間")]
    public float fadeTime = 0.2f;

    [Header("==== 定位參數 ====")]
    public float desiredAccuracyMeters = 10f;
    public float updateDistanceMeters = 5f;
    public int initTimeoutSeconds = 15;
    public int fixTimeoutSeconds = 20;

    [Header("==== Editor 模擬設定 ====")]
    [Tooltip("在 Unity Editor 使用此模擬位置，避免需要手機 GPS")]
    public bool useEditorMock = true;
    public double editorMockLat = 25.033968;   // 台北 101
    public double editorMockLng = 121.564468;

    [Header("==== 偵錯輸出 ====")]
    [Tooltip("輸出訊息到 UI TMP_Text")]
    public TMP_Text debugText;
    public bool verboseLog = true;

    // ===== 私有成員 =====
    GameObject _pinInstance;
    string _lastAddress = "";
    Geocoder _geocoder;

    void Awake()
    {
        if (whereAmIButton) whereAmIButton.onClick.AddListener(OnClickWhereAmI);

        ShowLoading(false);
        SetupPanel(addressPanel, false);

        // 初始化 Mapbox Geocoder（需先在 Project Settings > Mapbox 設定 Access Token）
        _geocoder = MapboxAccess.Instance != null ? MapboxAccess.Instance.Geocoder : null;

#if UNITY_ANDROID
        // Android 權限請求
        try
        {
            var hasFine = UnityEngine.Android.Permission.HasUserAuthorizedPermission(UnityEngine.Android.Permission.FineLocation);
            if (!hasFine)
            {
                SetDebug("需要定位權限，請允許。");
                UnityEngine.Android.Permission.RequestUserPermission(UnityEngine.Android.Permission.FineLocation);
            }
        }
        catch { }
#endif
    }

    // ==== UI 事件 ====
    public void OnClickWhereAmI()
    {
        StopAllCoroutines();
        StartCoroutine(LocateAndShow());
    }

    // 主流程：定位 → 放置圖釘 → 顯示地址
    IEnumerator LocateAndShow()
    {
        ShowLoading(true);
        SetDebug("開始定位…");

#if UNITY_EDITOR
        if (useEditorMock)
        {
            SetDebug($"使用 Editor 模擬位置 lat={editorMockLat:F6}, lng={editorMockLng:F6}");
            yield return StartCoroutine(PlaceAndCenterAndGeocode(editorMockLat, editorMockLng, isEditorMock: true));
            ShowLoading(false);
            yield break;
        }
#endif

        if (!Input.location.isEnabledByUser)
        {
            SetDebug("定位功能未開啟，請檢查系統設定。");
            ShowLoading(false);
            yield break;
        }

        Input.compass.enabled = true;
        Input.location.Start(desiredAccuracyMeters, updateDistanceMeters);
        SetDebug("啟動定位服務…");

        // 初始化等待
        int t = 0;
        while (Input.location.status == LocationServiceStatus.Initializing && t < initTimeoutSeconds)
        {
            SetDebug($"等待定位初始化 {t + 1}s");
            yield return new WaitForSeconds(1f);
            t++;
        }
        if (Input.location.status != LocationServiceStatus.Running)
        {
            SetDebug($"定位失敗，狀態={Input.location.status}");
            ShowLoading(false);
            yield break;
        }

        // 等待第一筆有效數據
        t = 0;
        SetDebug("等待定位數據…");
        while (Input.location.lastData.latitude == 0f &&
               Input.location.lastData.longitude == 0f &&
               t < fixTimeoutSeconds)
        {
            yield return new WaitForSeconds(1f);
            t++;
        }
        if (Input.location.status != LocationServiceStatus.Running)
        {
            SetDebug("定位中斷。");
            ShowLoading(false);
            yield break;
        }

        var data = Input.location.lastData;
        SetDebug($"取得位置 lat={data.latitude:F6}, lng={data.longitude:F6}");
        yield return StartCoroutine(PlaceAndCenterAndGeocode(data.latitude, data.longitude, isEditorMock: false));
        ShowLoading(false);
    }

    // 放置圖釘 & 地圖移動 & 地址查詢
    IEnumerator PlaceAndCenterAndGeocode(double lat, double lng, bool isEditorMock)
    {
        var ll = new Vector2d(lat, lng);

        if (!map)
        {
            SetDebug("Map 未設定，請在 Inspector 綁定 AbstractMap。");
            yield break;
        }

        // 放置或更新圖釘
        var worldPos = map.GeoToWorldPosition(ll, true);
        worldPos.y += pinYOffset;

        if (_pinInstance == null)
        {
            var prefab = pinPrefab != null ? pinPrefab : new GameObject("MyLocationPin");
            _pinInstance = Instantiate(prefab, worldPos, Quaternion.identity, map.transform);
        }
        _pinInstance.transform.position = worldPos;

        // 地圖置中
        if (centerMapOnLocate)
        {
            map.SetCenterLatitudeLongitude(ll);
            map.SetZoom(centerZoom);
            map.UpdateMap();

            yield return null;
            var p = _pinInstance.transform.position;
            p.y = map.transform.position.y + pinYOffset;
            _pinInstance.transform.position = p;
        }

        // 地址查詢
        _lastAddress = isEditorMock ? "[Editor 模擬地址]" : "[查詢中…]";
        UpdateAddressText();
        SetDebug("開始逆向地理編碼…");
        yield return StartCoroutine(ReverseGeocode(lat, lng));

        if (autoShowAddress) ShowAddress(true);
        SetDebug($"地址：{_lastAddress}");
    }

    // 逆向地理編碼
    IEnumerator ReverseGeocode(double lat, double lng)
    {
        if (_geocoder == null)
        {
            _lastAddress = $"Lat {lat:F6}, Lng {lng:F6}";
            UpdateAddressText();
            yield break;
        }

        bool done = false;

        var req = new ReverseGeocodeResource(new Vector2d(lat, lng));
        req.Types = new[] { "address", "place", "poi" };

        _geocoder.Geocode(req, (ReverseGeocodeResponse res) =>
        {
            done = true;
            try
            {
                if (res == null || res.Features == null || res.Features.Count == 0)
                {
                    _lastAddress = $"Lat {lat:F6}, Lng {lng:F6}";
                }
                else
                {
                    var f = res.Features[0];
                    _lastAddress = !string.IsNullOrEmpty(f.PlaceName)
                                   ? f.PlaceName
                                   : $"Lat {lat:F6}, Lng {lng:F6}";
                }
            }
            catch
            {
                _lastAddress = $"Lat {lat:F6}, Lng {lng:F6}";
            }
            UpdateAddressText();
        });

        // 最多等 6 秒
        float timeout = 6f, timer = 0f;
        while (!done && timer < timeout)
        {
            timer += Time.deltaTime;
            yield return null;
        }

        if (!done)
        {
            _lastAddress = $"Lat {lat:F6}, Lng {lng:F6}";
            UpdateAddressText();
        }
    }

    // UI 更新
    void UpdateAddressText()
    {
        if (addressText) addressText.text = _lastAddress;
    }

    public void ShowAddress(bool show)
    {
        SetupPanel(addressPanel, show);
    }

    public void HideAddress()
    {
        ShowAddress(false);
    }

    public void CopyAddressToClipboard()
    {
        if (!string.IsNullOrEmpty(_lastAddress))
            GUIUtility.systemCopyBuffer = _lastAddress;
    }

    void ShowLoading(bool show)
    {
        if (!loadingHint) return;
        loadingHint.alpha = show ? 1f : 0f;
        loadingHint.interactable = show;
        loadingHint.blocksRaycasts = show;
    }

    void SetupPanel(CanvasGroup cg, bool show)
    {
        if (!cg) return;
        StopCoroutine(nameof(FadeCanvas));
        StartCoroutine(FadeCanvas(cg, show ? 1f : 0f));
        cg.interactable = show;
        cg.blocksRaycasts = show;
    }

    IEnumerator FadeCanvas(CanvasGroup cg, float target)
    {
        float start = cg.alpha;
        float t = 0f;
        while (t < fadeTime)
        {
            t += Time.deltaTime;
            cg.alpha = Mathf.Lerp(start, target, t / fadeTime);
            yield return null;
        }
        cg.alpha = target;
    }

    // 偵錯輸出
    void SetDebug(string msg)
    {
        if (verboseLog) Debug.Log("[WhereAmI] " + msg);
        if (debugText) debugText.text = msg;
    }
}
