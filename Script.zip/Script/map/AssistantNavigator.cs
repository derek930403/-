using System;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class AssistantNavigator : MonoBehaviour
{
    [Header("==== UI 設定 ====")]
    public CanvasGroup panelGroup;
    public TMP_InputField addressInput;
    public Button departButton;
    public Button closeButton;

    [Header("==== 行為設定 ====")]
    [Tooltip("淡入淡出時間")]
    public float fadeTime = 0.25f;
    [Tooltip("是否記住上次輸入")]
    public bool rememberLastInput = true;
    public string playerPrefsKey = "AssistantNav_LastAddr";

    // ===== 狀態變數 =====
    bool _isShowing = false;
    float _fadeVel = 0f;
    bool _navigating = false;        // 是否正在導航
    bool _hasFocus = true;           // App 是否有焦點 (iOS 用來判斷是否跳轉到 Google Maps)
    Coroutine _iosFallbackCo = null; // iOS 備援 Coroutine

    void Awake()
    {
        if (panelGroup != null)
        {
            panelGroup.alpha = 0f;
            panelGroup.interactable = false;
            panelGroup.blocksRaycasts = false;
        }
        gameObject.SetActive(false);

        if (departButton) departButton.onClick.AddListener(OnClickDepart);
        if (closeButton) closeButton.onClick.AddListener(Hide);

        // Enter 觸發送出
        if (addressInput) addressInput.onSubmit.AddListener(_ => OnClickDepart());
    }

    void OnEnable()
    {
        if (rememberLastInput && addressInput != null && PlayerPrefs.HasKey(playerPrefsKey))
            addressInput.text = PlayerPrefs.GetString(playerPrefsKey, "");
    }

    void OnDestroy()
    {
        if (departButton) departButton.onClick.RemoveListener(OnClickDepart);
        if (closeButton) closeButton.onClick.RemoveListener(Hide);
        if (addressInput) addressInput.onSubmit.RemoveAllListeners();
    }

    void OnApplicationFocus(bool hasFocus) => _hasFocus = hasFocus;

    void Update()
    {
        if (panelGroup == null) return;
        float target = _isShowing ? 1f : 0f;
        panelGroup.alpha = Mathf.SmoothDamp(panelGroup.alpha, target, ref _fadeVel, fadeTime);
        bool interact = panelGroup.alpha > 0.98f ? true : (_isShowing && panelGroup.alpha > 0.2f);
        panelGroup.interactable = interact;
        panelGroup.blocksRaycasts = interact;
    }

    public void Show()
    {
        gameObject.SetActive(true);
        _isShowing = true;
        if (addressInput) StartCoroutine(FocusInputNextFrame());
    }

    public void Hide()
    {
        _isShowing = false;
        CancelInvoke(nameof(_Deactivate));
        Invoke(nameof(_Deactivate), fadeTime + 0.05f);
    }

    System.Collections.IEnumerator FocusInputNextFrame()
    {
        yield return null;
        addressInput?.ActivateInputField();
        addressInput?.Select();
    }

    void _Deactivate()
    {
        if (!_isShowing) gameObject.SetActive(false);
    }

    // ===== 導航觸發 =====
    public void OnClickDepart()
    {
        if (_navigating) return; // 避免短時間內連續觸發
        _navigating = true;
        Invoke(nameof(_ResetNavigating), 0.6f);

        string raw = addressInput ? addressInput.text.Trim() : "";
        if (string.IsNullOrEmpty(raw))
        {
            Debug.LogWarning("[AssistantNavigator] 請輸入地址或 'lat,lng'");
            return;
        }
        if (rememberLastInput) PlayerPrefs.SetString(playerPrefsKey, raw);

        string webUrl = BuildGoogleMapsWebUrl(raw);
        string appUrl = BuildGoogleMapsAppUrl(raw);

#if UNITY_IOS
        // iOS 嘗試打開 App (comgooglemaps://)，若 0.5 秒後沒有成功，則自動 fallback 開啟瀏覽器
        if (_iosFallbackCo != null) StopCoroutine(_iosFallbackCo);
        _iosFallbackCo = StartCoroutine(OpenIOSWithFallback(appUrl, webUrl, 0.5f));
#else
        // Android / Windows / macOS / Editor：直接開啟 https (Android 會自動導向 App 如果有安裝)
        Debug.Log($"[AssistantNavigator] OpenURL (Web): {webUrl}");
        Application.OpenURL(webUrl);
#endif
    }

    void _ResetNavigating() => _navigating = false;

#if UNITY_IOS
    private System.Collections.IEnumerator OpenIOSWithFallback(string appUrl, string webUrl, float delay)
    {
        Debug.Log($"[AssistantNavigator] iOS try App: {appUrl}");
        Application.OpenURL(appUrl);

        float t = 0f;
        while (t < delay)
        {
            t += Time.unscaledDeltaTime;
            yield return null;
        }

        // 如果沒有跳去 Google Maps (仍然有焦點)，就 fallback 開啟瀏覽器
        if (_hasFocus)
        {
            Debug.Log($"[AssistantNavigator] iOS fallback to Web: {webUrl}");
            Application.OpenURL(webUrl);
        }
        else
        {
            Debug.Log("[AssistantNavigator] iOS app opened, skip web fallback.");
        }
    }
#endif

    // ===== URL 建構 =====
    string BuildGoogleMapsWebUrl(string input)
    {
        ParseLatLng(input, out double lat, out double lng, out bool isLatLng);
        string destination = isLatLng
            ? Uri.EscapeDataString($"{lat.ToString(CultureInfo.InvariantCulture)},{lng.ToString(CultureInfo.InvariantCulture)}")
            : Uri.EscapeDataString(input);

        return $"https://www.google.com/maps/dir/?api=1&origin=Current+Location&destination={destination}&travelmode=driving";
    }

    string BuildGoogleMapsAppUrl(string input)
    {
        ParseLatLng(input, out double lat, out double lng, out bool isLatLng);
        string daddr = isLatLng
            ? Uri.EscapeDataString($"{lat.ToString(CultureInfo.InvariantCulture)},{lng.ToString(CultureInfo.InvariantCulture)}")
            : Uri.EscapeDataString(input);

        return $"comgooglemaps://?daddr={daddr}&directionsmode=driving";
    }

    void ParseLatLng(string input, out double lat, out double lng, out bool ok)
    {
        lat = 0; lng = 0; ok = false;
        if (string.IsNullOrWhiteSpace(input)) return;

        // 替換中文逗號成英文逗號
        input = input.Replace('，', ',');

        var parts = input.Split(',');
        if (parts.Length != 2) return;

        bool latOk = double.TryParse(parts[0].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out lat);
        bool lngOk = double.TryParse(parts[1].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out lng);

        if (latOk && lngOk && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180)
            ok = true;
        else
            ok = false;
    }
}
