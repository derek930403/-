﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;
using Mapbox.Unity.Map;
using Mapbox.Utils;

public class POIGeo : MonoBehaviour
{
    public double lat;
    public double lng;
}

public class POILoader : MonoBehaviour
{
    [Header("Sources")]
    public TextAsset poiCSV;          // CSV with header row
    public GameObject poiPrefab;
    public Transform poiParent;       // 留空就掛在 map 下
    public AbstractMap map;

    [Header("Display")]
    public float yOffset = 10f;       // 抬高避免被地面遮住
    public int sortingOrder = 600;    // 排序提高避免被蓋住

    [Header("Interaction")]
    [Tooltip("點擊判定往四周多加幾個世界單位（越大越好點）")]
    public float colliderPadding = 0.6f;
    [Tooltip("碰撞器厚度（Y 方向），加厚更好打到 Ray")]
    public float colliderThickness = 2.0f;

    [Header("Icon rules (by CSV Category)")]
    public Sprite defaultSprite;

    [Header("Photos")]
    [Tooltip("若 CSV 只有 photo_ref，可在這裡填你的 Cloudflare Worker base，如 https://xxx.workers.dev/ ，會自動把 ref 接在後面組成 photoUrl。")]
    public string photoProxyBase = "";

    [Tooltip("在 Console 印欄位對應與前幾筆照片欄位，方便除錯")]
    public bool logPhotoDebug = true;

    [System.Serializable]
    public class IconRule
    {
        public string category;
        [TextArea(1, 3)] public string keywordsLine;
        public Sprite sprite;
        [HideInInspector] public int hitCount;

        public IEnumerable<string> Keywords()
        {
            if (string.IsNullOrWhiteSpace(keywordsLine)) yield break;
            var parts = keywordsLine.Split(
                new char[] { ',', '，', '；', ';', '、', ' ' },
                System.StringSplitOptions.RemoveEmptyEntries);
            foreach (var p in parts)
            {
                var k = p.Replace("　", "").Trim();
                if (k.Length > 0) yield return k;
            }
        }
    }
    public List<IconRule> iconRules = new List<IconRule>();

    // =========================
    // 【新增】收集所有生成的 POI，供篩選顯示用
    // =========================
    private readonly List<GameObject> allPOIs = new List<GameObject>();

    void OnEnable() { if (map) map.OnUpdated += RefreshAllPOIPositions; }
    void OnDisable() { if (map) map.OnUpdated -= RefreshAllPOIPositions; }

    void Start()
    {
        if (!poiCSV || !poiPrefab || !map)
        {
            Debug.LogError("POILoader：poiCSV / poiPrefab / map 必填。");
            return;
        }
        StartCoroutine(LoadPOIs());
    }

    // ===== CSV helpers =====
    static List<string> SplitCsvLine(string line)
    {
        var res = new List<string>();
        if (line == null) return res;
        var sb = new StringBuilder(line.Length);
        bool inQ = false;
        for (int i = 0; i < line.Length; i++)
        {
            char c = line[i];
            if (c == '"')
            {
                if (inQ && i + 1 < line.Length && line[i + 1] == '"') { sb.Append('"'); i++; }
                else inQ = !inQ;
            }
            else if (c == ',' && !inQ) { res.Add(sb.ToString()); sb.Length = 0; }
            else sb.Append(c);
        }
        res.Add(sb.ToString());
        return res;
    }

    static string Norm(string s) => (s ?? "").Trim().Trim('"').Replace("　", "");
    static string LKey(string s) => Norm(s).ToLowerInvariant();

    static int FindIndex(Dictionary<string, int> map, params string[] keys)
    {
        foreach (var k in keys)
            if (map.TryGetValue(LKey(k), out int idx)) return idx;
        return -1;
    }

    static string NormCat(string s)
        => (s ?? "").Trim().Replace(" ", "").Replace("　", "").ToLowerInvariant();

    static bool CatMatch(string csvCategory, string ruleKey)
    {
        var src = NormCat(csvCategory);
        var key = NormCat(ruleKey);
        if (string.IsNullOrEmpty(src) || string.IsNullOrEmpty(key)) return false;
        if (src == key) return true;
        if (key.Length >= 2 && src.Contains(key)) return true;
        if (src.Length >= 2 && key.Contains(src)) return true;
        return false;
    }

    Sprite ResolveSpriteByCategory(string categoryValue)
    {
        foreach (var r in iconRules)
        {
            if (r == null || r.sprite == null) continue;
            foreach (var key in r.Keywords())
                if (CatMatch(categoryValue, key)) { r.hitCount++; return r.sprite; }
        }
        return null;
    }

    IEnumerator LoadPOIs()
    {
        var rows = poiCSV.text.Replace("\r", "").Split('\n');
        if (rows.Length <= 1) yield break;

        // 解析表頭
        var header = SplitCsvLine(rows[0]);
        var colMap = new Dictionary<string, int>();
        for (int c = 0; c < header.Count; c++)
            colMap[LKey(header[c])] = c;

        // ===== 欄位索引（擴充同義詞）=====
        // 名稱
        int idxName = FindIndex(colMap, "poiname", "poi_name", "name", "title", "地點", "地點名稱", "名稱");
        // 分類/服務/電話/地址
        int idxCat = FindIndex(colMap, "category", "type", "分類");
        int idxServ = FindIndex(colMap, "services", "service", "服務", "服務項目");
        int idxPhone = FindIndex(colMap, "phone", "tel", "電話");
        int idxAddr = FindIndex(colMap, "address", "addr", "地址");
        // 經緯度
        int idxLat = FindIndex(colMap, "latitude", "lat", "緯度");
        int idxLng = FindIndex(colMap, "longitude", "lng", "經度");

        // 照片（URL）
        int idxPhotoUrl = FindIndex(colMap,
            "photo_url", "photo url", "photourl",
            "image_url", "imageurl", "img_url",
            "pic_url", "picture_url",
            "圖片網址", "照片網址", "圖片連結", "照片連結", "圖片url", "照片url");

        // 照片（ref / reference）
        int idxPhotoRef = FindIndex(colMap,
            "photo_ref", "photoref", "photo_reference", "照片代碼", "照片ref");

        // 照片（本地 Resources 路徑）
        int idxPhotoPath = FindIndex(colMap,
            "photo", "image", "icon", "photo_path", "photopath", "圖片", "照片", "本地圖片", "資源路徑");

        if (idxLat < 0 || idxLng < 0)
        {
            Debug.LogError("CSV 缺少經緯度欄位（latitude/longitude）");
            yield break;
        }

        if (logPhotoDebug)
        {
            Debug.Log($"[POI] Columns: name={idxName}, cat={idxCat}, services={idxServ}, phone={idxPhone}, addr={idxAddr}, lat={idxLat}, lng={idxLng}, photoUrl={idxPhotoUrl}, photoRef={idxPhotoRef}, photoPath={idxPhotoPath}");
        }

        int count = 0;
        var inv = CultureInfo.InvariantCulture;

        for (int r = 1; r < rows.Length; r++)
        {
            var raw = rows[r];
            if (string.IsNullOrWhiteSpace(raw)) continue;

            var v = SplitCsvLine(raw);

            string name = idxName >= 0 && idxName < v.Count ? Norm(v[idxName]) : "";
            string category = idxCat >= 0 && idxCat < v.Count ? Norm(v[idxCat]) : "";
            string services = idxServ >= 0 && idxServ < v.Count ? Norm(v[idxServ]) : "";
            string phone = idxPhone >= 0 && idxPhone < v.Count ? Norm(v[idxPhone]) : "";
            string address = idxAddr >= 0 && idxAddr < v.Count ? Norm(v[idxAddr]) : "";

            string photoUrl = idxPhotoUrl >= 0 && idxPhotoUrl < v.Count ? Norm(v[idxPhotoUrl]) : "";
            string photoRef = idxPhotoRef >= 0 && idxPhotoRef < v.Count ? Norm(v[idxPhotoRef]) : "";
            string photoPath = idxPhotoPath >= 0 && idxPhotoPath < v.Count ? Norm(v[idxPhotoPath]) : "";

            if (!double.TryParse(Norm(v[idxLat]), NumberStyles.Float, inv, out double lat)) continue;
            if (!double.TryParse(Norm(v[idxLng]), NumberStyles.Float, inv, out double lng)) continue;

            // 若沒 url 但有 ref，且 Inspector 有填 Proxy，幫你組 url
            if (string.IsNullOrWhiteSpace(photoUrl) && !string.IsNullOrWhiteSpace(photoRef) && !string.IsNullOrWhiteSpace(photoProxyBase))
            {
                string baseUrl = photoProxyBase.Trim();
                if (!baseUrl.EndsWith("/") && !baseUrl.EndsWith("=")) baseUrl += "/";
                photoUrl = baseUrl + photoRef;
            }

            if (logPhotoDebug && count < 8) // 只印前幾筆就好
                Debug.Log($"[POI][Photo] name='{name}', url='{photoUrl}', ref='{photoRef}', path='{photoPath}'");

            // 世界座標
            Vector3 wp = map.GeoToWorldPosition(new Vector2d(lat, lng), true);
            wp.y += yOffset;

            // 生成
            var parent = poiParent ? poiParent : map.transform;
            var poi = Instantiate(poiPrefab, wp, Quaternion.Euler(-90f, 0f, 0f), parent);
            var sr = poi.GetComponent<SpriteRenderer>() ?? poi.AddComponent<SpriteRenderer>();
            sr.sortingOrder = sortingOrder;

            // 依分類決定圖示
            var chosen = ResolveSpriteByCategory(category) ?? defaultSprite;
            if (chosen) sr.sprite = chosen;

            // 3D collider（比較好被射線打到）
            foreach (var c2d in poi.GetComponents<Collider2D>()) Destroy(c2d);
            var rb2d = poi.GetComponent<Rigidbody2D>(); if (rb2d) Destroy(rb2d);
            var col = poi.GetComponent<BoxCollider>(); if (!col) col = poi.AddComponent<BoxCollider>();
            col.isTrigger = true;

            float pad = Mathf.Max(0f, colliderPadding);
            Vector3 size;
            if (sr.sprite != null)
            {
                float ppu = sr.sprite.pixelsPerUnit <= 0 ? 100f : sr.sprite.pixelsPerUnit;
                Vector2 sz = sr.sprite.rect.size / ppu;
                Vector3 sc = poi.transform.localScale;
                float width = Mathf.Max(0.4f, sz.x * sc.x + pad * 2f);
                float depth = Mathf.Max(0.4f, sz.y * sc.y + pad * 2f);
                size = new Vector3(width, Mathf.Max(0.05f, colliderThickness), depth);
            }
            else size = new Vector3(1f + pad * 2f, Mathf.Max(0.05f, colliderThickness), 1f + pad * 2f);

            col.size = size;
            col.center = Vector3.zero;

            // 互動
            if (!poi.TryGetComponent<POIInteraction>(out _)) poi.AddComponent<POIInteraction>();

            // 綁經緯度（地圖移動用）
            var geo = poi.GetComponent<POIGeo>() ?? poi.AddComponent<POIGeo>();
            geo.lat = lat;
            geo.lng = lng;

            // 寫 POIData
            var data = poi.GetComponent<POIData>();
            if (data != null)
            {
                data.poiName = string.IsNullOrWhiteSpace(name) ? "無" : name;
                data.category = string.IsNullOrWhiteSpace(category) ? "無" : category;
                data.services = string.IsNullOrWhiteSpace(services) ? "無" : services;
                data.phone = string.IsNullOrWhiteSpace(phone) ? "無" : phone;
                data.address = string.IsNullOrWhiteSpace(address) ? "無" : address;
                data.latitude = lat;
                data.longitude = lng;

                // 照片欄位：同步填兩種命名
                data.photoUrl = photoUrl;
                data.photo_url = photoUrl;
                data.photo_ref = photoRef;
                data.photoPath = photoPath;

                // 本地 Resources 備援
                if (string.IsNullOrWhiteSpace(photoUrl) && !string.IsNullOrWhiteSpace(photoPath))
                    data.photoSprite = Resources.Load<Sprite>(photoPath);

                data.iconName = sr.sprite ? sr.sprite.name : "";
            }

            // =========================
            // 【修改】收集 POI 以供後續按鈕篩選
            // =========================
            allPOIs.Add(poi);

            count++;
            if (count % 40 == 0) yield return null;
        }

        foreach (var r in iconRules)
            if (r != null && r.sprite != null)
                Debug.Log($"[IconRule] {(string.IsNullOrEmpty(r.category) ? r.sprite.name : r.category)} 命中 {r.hitCount} 筆");

        Debug.Log($"成功載入 {count} 筆 POI（含照片欄位偵測與 Proxy 組合）");
    }

    void RefreshAllPOIPositions()
    {
        if (map == null) return;
        var parent = poiParent ? poiParent : map.transform;

        var geos = parent.GetComponentsInChildren<POIGeo>(true);
        for (int i = 0; i < geos.Length; i++)
        {
            var g = geos[i];
            var t = g.transform;
            var wp = map.GeoToWorldPosition(new Vector2d(g.lat, g.lng), true);
            wp.y += yOffset;
            t.position = wp;
            t.rotation = Quaternion.Euler(-90f, 0f, 0f);
        }
    }

    // =========================
    // 【新增】五顆按鈕會用到的公開方法
    // =========================

    /// <summary>顯示全部 POI（「全部顯示」按鈕綁這個）</summary>
    public void ShowAllPOIs()
    {
        for (int i = 0; i < allPOIs.Count; i++)
            if (allPOIs[i]) allPOIs[i].SetActive(true);
    }

    /// <summary>
    /// 依分類關鍵字顯示（四顆分類按鈕各自綁這個，參數填「咖啡」「運動」…）
    /// 使用內建 NormCat/CatMatch，支援全半形空白與互含。
    /// </summary>
    public void ShowCategoryByKeyword(string keyword)
    {
        string key = NormCat(keyword);
        for (int i = 0; i < allPOIs.Count; i++)
        {
            var go = allPOIs[i];
            if (!go) continue;
            var data = go.GetComponent<POIData>();
            bool on = (data != null) && CatMatch(data.category, key);
            go.SetActive(on);
        }
    }

    /// <summary>
    /// （可選）若四顆分類剛好對應 IconRule，可用索引篩圖示。
    /// </summary>
    public void ShowByIconRuleIndex(int ruleIndex)
    {
        if (ruleIndex < 0 || ruleIndex >= iconRules.Count || iconRules[ruleIndex]?.sprite == null)
            return;

        string targetSpriteName = iconRules[ruleIndex].sprite.name;
        for (int i = 0; i < allPOIs.Count; i++)
        {
            var go = allPOIs[i];
            if (!go) continue;
            var data = go.GetComponent<POIData>();
            bool on = (data != null) && data.iconName == targetSpriteName;
            go.SetActive(on);
        }
    }
}
