using System;
using System.Collections.Generic;
using UnityEngine;

public class TaskReminderService : MonoBehaviour
{
    public static TaskReminderService Instance { get; private set; }

    // ===== Backend 選項 =====
    [Header("Backend")]
    [Tooltip("關閉時完全不啟動後端輪詢（只用本機排程也能跑）")]
    public bool requireBackend = false;

    [Header("與後端通訊的客戶端(常駐)")]
    public TaskClient taskClient; // 可不綁；Awake 會自動找/自建

    [Header("需要輪詢的任務名清單（可留空，改用動態註冊）")]
    public List<string> taskNames = new List<string>();

    // ===== 全域面板（可選）=====
    [Header("（可選）全域提醒面板 Prefab")]
    [Tooltip("拖入 GlobalReminderCanvas 的 Prefab；啟動時會自動生成在服務底下")]
    public GameObject globalReminderCanvasPrefab;

    // ===== 狀態 =====
    private readonly HashSet<string> _pending = new HashSet<string>(); // 待提醒
    private readonly HashSet<string> _completed = new HashSet<string>(); // 已完成

    public event Action<string> ReminderReceived; // 任務被提醒（後端或本機）
    public event Action StateChanged;             // 待提醒/完成清單變更

    // ===== 持久化（含排程）=====
    [Header("Persistence")]
    [SerializeField] private string saveKey = "TRS_STATE_V2";

    // ==================【新增】自訂義時間接口（給 UI 呼叫）==================

    // 先清掉某任務的所有舊排程，再加新的（確保只有使用者最新設定）
    public void ReplaceSchedules_OnceLocal(string taskName, DateTime localDateTime)
    {
        CancelSchedules(taskName);
        ScheduleOnceLocal(taskName, localDateTime);
        Debug.Log($"[TRS] ReplaceSchedules_OnceLocal: {taskName} @ {localDateTime:yyyy-MM-dd HH:mm}");
    }

    public void ReplaceSchedules_DailyLocal(string taskName, int hour, int minute)
    {
        CancelSchedules(taskName);
        var tod = new TimeSpan(hour, minute, 0);
        ScheduleDailyLocal(taskName, tod);
        Debug.Log($"[TRS] ReplaceSchedules_DailyLocal: {taskName} @ {hour:D2}:{minute:D2} (每日)");
    }

    public void ReplaceSchedules_WeeklyLocal(string taskName, DayOfWeek day, int hour, int minute)
    {
        CancelSchedules(taskName);
        var tod = new TimeSpan(hour, minute, 0);
        ScheduleWeeklyLocal(taskName, day, tod);
        Debug.Log($"[TRS] ReplaceSchedules_WeeklyLocal: {taskName} {day} @ {hour:D2}:{minute:D2} (每週)");
    }

    // 讀回目前排程（你之前已經有 GetSchedulesSnapshot，可直接用）
    // 這裡加一個好讀的字串輸出，方便 Debug UI 或 Console 檢查
    public string DumpSchedules()
    {
        var list = GetSchedulesSnapshot();
        if (list == null || list.Count == 0) return "[TRS] (no schedules)";
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.AppendLine($"[TRS] Schedules ({list.Count}):");
        foreach (var s in list)
        {
            string mode = s.repeatIntervalTicks.HasValue
                ? (s.weeklyDay.HasValue ? $"Weekly(DOW={s.weeklyDay})" : "Daily")
                : "Once";
            string flag = s.canceled ? " (canceled)" : "";
            sb.AppendLine($"- {s.taskName} | {mode} | dueLocal={s.dueLocal:yyyy-MM-dd HH:mm}{flag}");
        }
        return sb.ToString();
    }


    /// <summary>
    /// 取得所有已經註冊過的任務名稱
    /// （包含一開始 taskNames 列表 + 動態 RegisterTaskName 加進來的）
    /// </summary>
    public IReadOnlyCollection<string> GetAllRegisteredNames()
    {
        return taskNames.AsReadOnly();
    }

    [Serializable]
    private class PersistScheduleItem
    {
        public string taskName;
        public long dueUtcTicks;           // DateTime.UtcTicks
        public long? repeatIntervalTicks;   // null=一次性
        public int? weeklyDay;             // null=非每週
        public bool canceled;
    }

    [Serializable]
    private class PersistState
    {
        public List<string> pending = new List<string>();
        public List<string> completed = new List<string>();
        public List<PersistScheduleItem> schedules = new List<PersistScheduleItem>();
    }
    // 對 SpecialTaskList 之類的 UI 暴露排程快照
    [Serializable]
    public struct ScheduleDto
    {
        public string taskName;
        public System.DateTime dueLocal;
        public long? repeatIntervalTicks; // null=一次性
        public int? weeklyDay;
        public bool canceled;
    }

    public static System.Collections.Generic.List<ScheduleDto> GetSchedulesSnapshot()
    {
        var list = new System.Collections.Generic.List<ScheduleDto>();
        if (Instance == null) return list;

        foreach (var s in Instance._schedule)
        {
            list.Add(new ScheduleDto
            {
                taskName = s.taskName,
                dueLocal = s.dueUtc.ToLocalTime(),
                repeatIntervalTicks = s.repeatInterval.HasValue ? (long?)s.repeatInterval.Value.Ticks : null,
                weeklyDay = s.weeklyDay.HasValue ? (int?)s.weeklyDay.Value : null,
                canceled = s.canceled
            });
        }
        return list;
    }


    // ===== 單例 & 常駐 =====
    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        Application.runInBackground = true;

        // TaskClient 自動找/自建
        if (taskClient == null) taskClient = FindObjectOfType<TaskClient>();
        if (taskClient == null)
        {
            var go = new GameObject("TaskClient_Auto");
            go.transform.SetParent(transform, false);
            taskClient = go.AddComponent<TaskClient>();
        }

        // 自動生成全域面板
        if (globalReminderCanvasPrefab != null && transform.Find("GlobalReminderCanvas") == null)
        {
            var canvas = Instantiate(globalReminderCanvasPrefab);
            canvas.name = "GlobalReminderCanvas";
            canvas.transform.SetParent(transform, false);
        }

        // 載回上次狀態（含排程）
        LoadState();
    }

    void OnEnable()
    {
        if (requireBackend && taskClient != null)
        {
            taskClient.ReminderReceived -= OnClientReminder;
            taskClient.ReminderReceived += OnClientReminder;
        }
        StartSchedulerLoop();
    }

    void OnDisable()
    {
        if (requireBackend && taskClient != null)
            taskClient.ReminderReceived -= OnClientReminder;
        StopSchedulerLoop();
    }

    // ===== 後端輪詢（可選）=====
    public void EnsurePollingStarted()
    {
        if (!requireBackend) return;
        if (taskClient == null)
        {
            Debug.LogWarning("[TaskReminderService] requireBackend=true 但找不到 TaskClient，已跳過輪詢啟動。");
            return;
        }
        foreach (var name in taskNames)
            taskClient.StartReminderPolling(name);
    }

    public void RegisterTaskName(string taskName)
    {
        if (string.IsNullOrEmpty(taskName)) return;
        if (!taskNames.Contains(taskName))
        {
            taskNames.Add(taskName);
            if (requireBackend && taskClient != null)
                taskClient.StartReminderPolling(taskName);
        }
    }
    private void OnClientReminder(string taskName) => TriggerReminder(taskName);

    // ===== 查詢 / 操作 =====
    public IReadOnlyCollection<string> GetPending() => _pending;
    public bool IsCompleted(string taskName) => _completed.Contains(taskName);

    public void MarkCompleted(string taskName)
    {
        if (string.IsNullOrEmpty(taskName)) return;
        _completed.Add(taskName);
        _pending.Remove(taskName);
        StateChanged?.Invoke();
        SaveState();

        if (requireBackend && taskClient != null)
            taskClient.MarkTaskCompleted(taskName);
    }

    private void TriggerReminder(string taskName)
    {
        if (string.IsNullOrEmpty(taskName)) return;
        if (_completed.Contains(taskName)) return;

        if (_pending.Add(taskName))
        {
            ReminderReceived?.Invoke(taskName);
            StateChanged?.Invoke();
            SaveState();
        }
    }

    // ===== 本機排程（一次性 / 每日 / 每週）=====
    [Serializable]
    private class ScheduledItem
    {
        public string taskName;
        public DateTime dueUtc;
        public TimeSpan? repeatInterval; // null=一次性；每日=1天；每週=7天
        public DayOfWeek? weeklyDay;
        public bool canceled;
    }

    private readonly List<ScheduledItem> _schedule = new List<ScheduledItem>();
    private Coroutine _schedulerCo;

    /// 一次性：在本地時間某刻提醒一次
    public void ScheduleOnceLocal(string taskName, DateTime localTime)
        => AddSchedule(taskName, localTime.ToUniversalTime(), null, null);

    /// 每日：每天本地時刻提醒
    public void ScheduleDailyLocal(string taskName, TimeSpan timeOfDayLocal)
    {
        var nextLocal = NextLocalDateTime(DateTime.Now, timeOfDayLocal);
        AddSchedule(taskName, nextLocal.ToUniversalTime(), TimeSpan.FromDays(1), null);
    }

    /// 每週：每週某天本地時刻提醒
    public void ScheduleWeeklyLocal(string taskName, DayOfWeek day, TimeSpan timeOfDayLocal)
    {
        var nextLocal = NextWeeklyLocalDateTime(DateTime.Now, day, timeOfDayLocal);
        AddSchedule(taskName, nextLocal.ToUniversalTime(), TimeSpan.FromDays(7), day);
    }

    /// 取消某任務所有排程
    public void CancelSchedules(string taskName)
    {
        foreach (var it in _schedule)
            if (it.taskName == taskName) it.canceled = true;
        SaveState();
    }

    private void AddSchedule(string taskName, DateTime dueUtc, TimeSpan? interval, DayOfWeek? weekly)
    {
        if (string.IsNullOrEmpty(taskName)) return;
        _schedule.Add(new ScheduledItem
        {
            taskName = taskName,
            dueUtc = dueUtc,
            repeatInterval = interval,
            weeklyDay = weekly,
            canceled = false
        });
        RestartSchedulerLoop();
        SaveState(); // ★ 新增排程就馬上保存
    }

    private static DateTime NextLocalDateTime(DateTime nowLocal, TimeSpan todLocal)
    {
        var t = nowLocal.Date + todLocal;
        if (t <= nowLocal) t = t.AddDays(1);
        return t;
    }

    private static DateTime NextWeeklyLocalDateTime(DateTime nowLocal, DayOfWeek day, TimeSpan todLocal)
    {
        int diff = ((int)day - (int)nowLocal.DayOfWeek + 7) % 7;
        var t = nowLocal.Date.AddDays(diff) + todLocal;
        if (t <= nowLocal) t = t.AddDays(7);
        return t;
    }

    private void StartSchedulerLoop()
    {
        if (_schedulerCo != null) return;
        _schedulerCo = StartCoroutine(SchedulerLoop());
    }

    private void StopSchedulerLoop()
    {
        if (_schedulerCo != null) { StopCoroutine(_schedulerCo); _schedulerCo = null; }
    }

    private void RestartSchedulerLoop()
    {
        StopSchedulerLoop();
        StartSchedulerLoop();
    }

    private System.Collections.IEnumerator SchedulerLoop()
    {
        while (true)
        {
            _schedule.RemoveAll(s => s.canceled);

            DateTime? nearest = null;
            var nowUtc = DateTime.UtcNow;

            for (int i = 0; i < _schedule.Count; i++)
            {
                var s = _schedule[i];
                if (s.canceled) continue;

                if (s.dueUtc <= nowUtc)
                {
                    TriggerReminder(s.taskName);

                    if (s.repeatInterval.HasValue)
                    {
                        var step = s.repeatInterval.Value;
                        var due = s.dueUtc;
                        while (due <= nowUtc) due = due.Add(step); // 進位到下一次
                        s.dueUtc = due;
                    }
                    else
                    {
                        s.canceled = true;
                    }

                    StateChanged?.Invoke();
                    SaveState();
                    continue;
                }

                if (!nearest.HasValue || s.dueUtc < nearest.Value)
                    nearest = s.dueUtc;
            }

            if (!nearest.HasValue)
            {
                yield return new WaitForSecondsRealtime(1f);
                continue;
            }

            float waitSec = Mathf.Max(0f, (float)(nearest.Value - DateTime.UtcNow).TotalSeconds);
            if (waitSec > 0f) yield return new WaitForSecondsRealtime(waitSec);
        }
    }

    // ===== 持久化（含排程）=====
    private void SaveState()
    {
        try
        {
            var st = new PersistState();

            foreach (var p in _pending) st.pending.Add(p);
            foreach (var c in _completed) st.completed.Add(c);

            foreach (var s in _schedule)
            {
                st.schedules.Add(new PersistScheduleItem
                {
                    taskName = s.taskName,
                    dueUtcTicks = s.dueUtc.Ticks,
                    repeatIntervalTicks = s.repeatInterval.HasValue ? (long?)s.repeatInterval.Value.Ticks : null,
                    weeklyDay = s.weeklyDay.HasValue ? (int?)s.weeklyDay.Value : null,
                    canceled = s.canceled
                });
            }

            var json = JsonUtility.ToJson(st);
            PlayerPrefs.SetString(saveKey, json);
            PlayerPrefs.Save();
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[TRS] SaveState failed: {e.Message}");
        }
    }

    private void LoadState()
    {
        try
        {
            if (!PlayerPrefs.HasKey(saveKey)) return;
            var json = PlayerPrefs.GetString(saveKey, "");
            if (string.IsNullOrEmpty(json)) return;

            var st = JsonUtility.FromJson<PersistState>(json);

            _pending.Clear();
            _completed.Clear();
            _schedule.Clear();

            if (st.pending != null) foreach (var p in st.pending) _pending.Add(p);
            if (st.completed != null) foreach (var c in st.completed) _completed.Add(c);

            if (st.schedules != null)
            {
                foreach (var ps in st.schedules)
                {
                    var dueUtc = new DateTime(ps.dueUtcTicks, DateTimeKind.Utc);
                    TimeSpan? interval = ps.repeatIntervalTicks.HasValue
                        ? new TimeSpan(ps.repeatIntervalTicks.Value)
                        : (TimeSpan?)null;
                    DayOfWeek? weekly = ps.weeklyDay.HasValue
                        ? (DayOfWeek?)ps.weeklyDay.Value
                        : null;

                    _schedule.Add(new ScheduledItem
                    {
                        taskName = ps.taskName,
                        dueUtc = dueUtc,
                        repeatInterval = interval,
                        weeklyDay = weekly,
                        canceled = ps.canceled
                    });
                }
            }

            StateChanged?.Invoke();  // 讓 UI 初始就重繪
            Debug.Log($"[TRS] Loaded state: pending={_pending.Count}, completed={_completed.Count}, schedule={_schedule.Count}");
            foreach (var s in _schedule) Debug.Log($"[TRS] Scheduled: {s.taskName} @ {s.dueUtc.ToLocalTime():yyyy-MM-dd HH:mm} repeat={(s.repeatInterval.HasValue ? s.repeatInterval.Value.ToString() : "once")}");

            RestartSchedulerLoop();  // 排程按載回的時間繼續運作
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[TRS] LoadState failed: {e.Message}");
        }
    }
}