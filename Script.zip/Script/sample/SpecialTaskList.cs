﻿using System.Text;
using UnityEngine;
using TMPro;

public class SpecialTaskList : MonoBehaviour
{
    [Header("顯示自定義排程的文字元件")]
    public TMP_Text listText;

    private TaskReminderService svc;

    void OnEnable()
    {
        svc = TaskReminderService.Instance;
        if (svc == null) { Debug.LogError("[SpecialTaskList] 找不到 TaskReminderService"); return; }

        // 每次狀態改變（包含排程到期、完成、載入）都重繪一次
        svc.StateChanged -= OnStateChanged;
        svc.StateChanged += OnStateChanged;

        Redraw();
    }

    void OnDisable()
    {
        if (svc != null) svc.StateChanged -= OnStateChanged;
    }

    void OnStateChanged() => Redraw();

    void Redraw()
    {
        if (listText == null || svc == null) return;

        var schedules = TaskReminderService.GetSchedulesSnapshot(); // 下面我們會加這個 API
        if (schedules.Count == 0)
        {
            listText.text = "尚無自定義提醒";
            return;
        }

        var sb = new StringBuilder();
        sb.AppendLine("已設定的自定義提醒：");
        foreach (var s in schedules)
        {
            // 尚未取消、且尚未到期的才列
            if (s.canceled) continue;

            string repeat = s.repeatIntervalTicks.HasValue
                ? (s.weeklyDay.HasValue ? $"每週{(System.DayOfWeek)s.weeklyDay.Value}" : "每日")
                : "一次性";

            sb.AppendLine($"• {s.taskName} - {s.dueLocal:MM/dd HH:mm}（{repeat}）");
        }
        listText.text = sb.ToString();
    }
}
