using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ReminderItemView : MonoBehaviour
{
    public Button starButton;
    public Button deleteButton;
    public TMP_Text label;

    // �i�s�W�j���~���i�H���U�R���ƥ�
    public Action<ReminderItemView> OnDelete;

    public void SetLabel(string text)
    {
        if (label != null) label.text = text;
    }

    void Awake()
    {
        if (deleteButton != null)
        {
            deleteButton.onClick.RemoveAllListeners();
            deleteButton.onClick.AddListener(() => OnDelete?.Invoke(this));
        }
    }
}
