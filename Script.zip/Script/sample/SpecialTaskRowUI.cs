using UnityEngine;
using TMPro;
using UnityEngine.UI;

/// <summary>
/// ������S�����Ȫ� UI �欰
/// </summary>
public class SpecialTaskRowUI : MonoBehaviour
{
    public TMP_Text label;
    public Button starButton;
    public Button deleteButton;

    private string taskName;
    private TaskReminderService svc;

    public void Bind(string name, TaskReminderService service)
    {
        taskName = name;
        svc = service;

        if (label != null) label.text = name;

        if (starButton != null)
        {
            starButton.onClick.RemoveAllListeners();
            starButton.onClick.AddListener(() => svc.MarkCompleted(taskName));
        }

        if (deleteButton != null)
        {
            deleteButton.onClick.RemoveAllListeners();
            deleteButton.onClick.AddListener(() => svc.CancelSchedules(taskName));
        }
    }
}
