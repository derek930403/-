using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GlobalReminderPanel : MonoBehaviour
{
    [Header("UI �j�w")]
    public Canvas rootCanvas;      // Screen Space - Overlay
    public CanvasGroup panelGroup; // ��Ӵ��ܭ��O
    public TMP_Text messageText;   // ���e
    public Button closeButton;     // �������s�]�i��^

    [Header("��ܦ欰")]
    public float fadeTime = 0.2f;
    public float autoHideSeconds = 3f; // 0 = ���۰���
    public int sortingOrder = 5000;

    private TaskReminderService svc;
    private Coroutine _autoHideCo;
    private bool _isShowing;

    void Awake()
    {
        if (rootCanvas != null)
        {
            rootCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            rootCanvas.sortingOrder = sortingOrder;
        }
        if (panelGroup != null)
        {
            panelGroup.alpha = 0f;
            panelGroup.interactable = false;
            panelGroup.blocksRaycasts = false;
            gameObject.SetActive(true);
        }
        if (closeButton != null)
            closeButton.onClick.AddListener(HideNow);
    }

    void Start()
    {
        svc = TaskReminderService.Instance;
        if (svc == null) { Debug.LogError("[GlobalReminderPanel] �䤣�� TaskReminderService"); return; }

        svc.ReminderReceived -= OnServiceReminder;
        svc.ReminderReceived += OnServiceReminder;

        svc.StateChanged -= OnServiceStateChanged;
        svc.StateChanged += OnServiceStateChanged;

        RefreshMessageFromService();
    }

    void OnDestroy()
    {
        if (svc != null)
        {
            svc.ReminderReceived -= OnServiceReminder;
            svc.StateChanged -= OnServiceStateChanged;
        }
    }

    void OnServiceReminder(string taskName)
    {
        RefreshMessageFromService();
        ShowNow(true);
    }

    void OnServiceStateChanged()
    {
        RefreshMessageFromService();
    }

    void RefreshMessageFromService()
    {
        if (messageText == null || svc == null) return;
        var pending = svc.GetPending();
        messageText.text = pending.Count == 0
            ? "�ثe�S���ݴ���������"
            : "�Ч������ȡG\n" + string.Join("\n", pending);
    }

    public void ShowNow(bool autoHide = true)
    {
        if (panelGroup == null) return;
        if (_autoHideCo != null) { StopCoroutine(_autoHideCo); _autoHideCo = null; }

        _isShowing = true;
        StartCoroutine(FadeTo(1f));
        panelGroup.interactable = true;
        panelGroup.blocksRaycasts = true;

        if (autoHide && autoHideSeconds > 0f)
            _autoHideCo = StartCoroutine(CoAutoHide());
    }

    public void HideNow()
    {
        if (panelGroup == null) return;
        if (_autoHideCo != null) { StopCoroutine(_autoHideCo); _autoHideCo = null; }

        _isShowing = false;
        StartCoroutine(FadeTo(0f));
        panelGroup.interactable = false;
        panelGroup.blocksRaycasts = false;
    }

    IEnumerator CoAutoHide()
    {
        yield return new WaitForSecondsRealtime(autoHideSeconds);
        if (_isShowing) HideNow();
    }

    IEnumerator FadeTo(float target)
    {
        if (fadeTime <= 0f) { panelGroup.alpha = target; yield break; }
        float t = 0f, start = panelGroup.alpha;
        while (t < fadeTime)
        {
            t += Time.unscaledDeltaTime;
            panelGroup.alpha = Mathf.Lerp(start, target, t / fadeTime);
            yield return null;
        }
        panelGroup.alpha = target;
    }

    public void OnBackgroundClick() => HideNow();
}
