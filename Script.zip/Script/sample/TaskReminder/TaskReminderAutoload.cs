using UnityEngine;

public static class TaskReminderAutoload
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void EnsureService()
    {
        if (TaskReminderService.Instance != null) return;

        var prefab = Resources.Load<GameObject>("TaskReminder/TaskReminderService");
        if (prefab == null)
        {
            Debug.LogWarning("[TRS] �䤣�� Resources/TaskReminder/TaskReminderService.prefab�]�Y�A������Φ۰ʸ��J�i�����^");
            return;
        }

        var go = Object.Instantiate(prefab);
        go.name = "TaskReminderService";
        Object.DontDestroyOnLoad(go);
        Debug.Log("[TRS] Service Auto-Loaded.");
    }
}
