using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using System.Text;
using System.IO;

[RequireComponent(typeof(AudioSource))]
public class ElevenLabsTTS : MonoBehaviour
{
    [Header("ElevenLabs API Key")]
    public string apiKey;

    [Header("Voice ID")]
    public string voiceID;

    public TextMeshProUGUI textSource;
    private string lastText = "";
    private AudioSource audioSource;

    void Start()
    {
        GameObject target = GameObject.Find("解答");
        if (target != null)
        {
            textSource = target.GetComponent<TextMeshProUGUI>();
        }
        else
        {
            Debug.LogError("找不到文字框");
            return;
        }

        audioSource = GetComponent<AudioSource>();
        StartCoroutine(CheckTextRoutine());
    }

    IEnumerator CheckTextRoutine()
    {
        while (true)
        {
            string currentText = textSource.text.Trim();
            if (!string.IsNullOrEmpty(currentText) && currentText != lastText)
            {
                lastText = currentText;
                yield return StartCoroutine(Speak(currentText));
            }
            yield return new WaitForSeconds(0.5f);
        }
    }

    IEnumerator Speak(string text)
    {
        string apiUrl = $"https://api.elevenlabs.io/v1/text-to-speech/{voiceID}?output_format=mp3_44100_128";

        string json = $"{{\"text\":\"{text}\",\"model_id\":\"eleven_multilingual_v2\"}}";

        UnityWebRequest request = new UnityWebRequest(apiUrl, "POST");
        byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
        request.uploadHandler = new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        request.SetRequestHeader("Accept", "audio/mpeg");
        request.SetRequestHeader("xi-api-key", apiKey);

        yield return request.SendWebRequest();

        if (request.result == UnityWebRequest.Result.Success)
        {
            byte[] audioData = request.downloadHandler.data;
            string path = Path.Combine(Application.persistentDataPath, "temp_tts.mp3");
            File.WriteAllBytes(path, audioData);

            using (UnityWebRequest audioReq = UnityWebRequestMultimedia.GetAudioClip("file://" + path, AudioType.MPEG))
            {
                yield return audioReq.SendWebRequest();

                if (audioReq.result == UnityWebRequest.Result.Success)
                {
                    AudioClip clip = DownloadHandlerAudioClip.GetContent(audioReq);
                    audioSource.clip = clip;
                    audioSource.Play();
                }
                else
                {
                    Debug.LogError("讀取音訊失敗: " + audioReq.error);
                }
            }
        }
        else
        {
            Debug.LogError("API錯誤：" + request.responseCode + "\n內容：" + request.downloadHandler.text);
        }
    }

}