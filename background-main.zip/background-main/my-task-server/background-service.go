package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"sync"
	"time"
)

type TaskState struct {
	LastUpdated      time.Time
	ReminderInterval time.Duration
	Completed        bool
}

var (
	taskStatus      = make(map[string]*TaskState)
	statusMux       sync.Mutex
	defaultInterval = 30 * time.Minute // 可改為 30 * time.Minute
)

// --------- 任務建立或更新時間 ---------
func handleTask(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		var req struct {
			TaskName         string `json:"taskName"`
			ReminderInterval int    `json:"reminderInterval"` // 秒為單位
		}
		err := json.NewDecoder(r.Body).Decode(&req)
		if err != nil || req.TaskName == "" {
			http.Error(w, "Invalid request", http.StatusBadRequest)
			return
		}

		statusMux.Lock()
		defer statusMux.Unlock()

		interval := time.Duration(req.ReminderInterval) * time.Second
		if interval <= 0 {
			interval = defaultInterval
		}

		taskStatus[req.TaskName] = &TaskState{
			LastUpdated:      time.Now(),
			ReminderInterval: interval,
			Completed:        false,
		}

		log.Printf("任務 [%s] 加入，提醒間隔：%v", req.TaskName, interval)

		json.NewEncoder(w).Encode(map[string]string{
			"message": "任務建立成功",
		})
	}
}

// --------- 查詢是否該提醒 ---------
func handleReminder(w http.ResponseWriter, r *http.Request) {
	taskName := r.URL.Query().Get("taskName")
	if taskName == "" {
		http.Error(w, "缺少 taskName", http.StatusBadRequest)
		return
	}

	statusMux.Lock()
	defer statusMux.Unlock()

	task, exists := taskStatus[taskName]
	if !exists {
		task = &TaskState{
			LastUpdated:      time.Now(),
			ReminderInterval: defaultInterval,
			Completed:        false,
		}
		taskStatus[taskName] = task
	}

	shouldRemind := false
	if !task.Completed && time.Since(task.LastUpdated) > task.ReminderInterval {
		shouldRemind = true
	}

	json.NewEncoder(w).Encode(map[string]any{
		"shouldRemind": shouldRemind,
	})
}

// --------- 回報任務完成 ---------
func handleComplete(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		TaskName string `json:"taskName"`
	}
	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil || req.TaskName == "" {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}

	statusMux.Lock()
	defer statusMux.Unlock()

	if task, ok := taskStatus[req.TaskName]; ok {
		task.Completed = true
		task.LastUpdated = time.Now()
		log.Printf("任務 [%s] 已完成，停止提醒", req.TaskName)
	}

	json.NewEncoder(w).Encode(map[string]string{
		"message": "完成狀態已更新",
	})
}

// --------- 主程式 ---------
func main() {
	http.HandleFunc("/task", handleTask)
	http.HandleFunc("/reminder", handleReminder)
	http.HandleFunc("/complete", handleComplete)

	// ✅ 從環境變數讀取 PORT（相容 Railway/Render）
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Println("後端伺服器啟動於 http://localhost:" + port)
	log.Fatal(http.ListenAndServe(":"+port, nil))
}
